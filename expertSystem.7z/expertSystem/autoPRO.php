<?php

abstract class Autopart
{
    protected $name;

    function __construct($name)
    {
        $this->name = $name;
    }

    abstract function AddAutopart();

    abstract function DeleteAutopart($id);
}

class Engine extends Autopart //класс двигателя
{
    public $engineCapacity; //объем двигателя
    public $numberOfCylinders; //число цилиндров двигателя
    public $enginePower; //мощность двигателя
    public $engineTorque; //крутящий момент двигателя
    public $gasolineConsumption; //расход бензина двигателя
    public $oilConsumption; //расход масла двигателя

    function __construct($name, $engineCapacity, $numberOfCylinders, $enginePower, $engineTorque, $gasolineConsumption, $oilConsumption)
    {
        $this->name = $name;
        $this->engineCapacity = $engineCapacity;
        $this->numberOfCylinders = $numberOfCylinders;
        $this->enginePower = $enginePower;
        $this->engineTorque = $engineTorque;
        $this->gasolineConsumption = $gasolineConsumption;
        $this->oilConsumption = $oilConsumption;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `engine` (`name`, `engineCapacity`, `countOfCylinders`, `enginePower`, `engineTorque`, `gasolineConsumption`, `oilConsumption`) 
        VALUES ('$this->name', '$this->engineCapacity', '$this->numberOfCylinders', '$this->enginePower', '$this->engineTorque', '$this->gasolineConsumption', '$this->oilConsumption')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `engine` WHERE `engine`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class Transmission extends Autopart
{
    public $transmissionType; //тип трансмиссии
    public $countOfGears; //количество передач
    public $typeOfDrive; //тип привода
    public $workResource; //заводской ресурс

    function __construct($name, $transmissionType, $countOfGears, $typeOfDrive, $workResource)
    {
        $this->name = $name;
        $this->transmissionType = $transmissionType;
        $this->countOfGears = $countOfGears;
        $this->typeOfDrive = $typeOfDrive;
        $this->workResource = $workResource;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `transmission` (`name`, `transmissionType`, `countOfGears`, `typeOfDrive`, `workResource`) 
        VALUES ('$this->name', '$this->transmissionType', '$this->countOfGears', '$this->typeOfDrive', '$this->workResource')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `transmission` WHERE `transmission`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class CoolingSystem extends Autopart
{
    public $radiatorMaterial; //материал радиатора
    public $hoseMaterial; //материал патрубков
    public $coolantVolume; //Объем охлаждающей жидкости

    function __construct($name, $radiatorMaterial, $hoseMaterial, $coolantVolume)
    {
        $this->name = $name;
        $this->radiatorMaterial = $radiatorMaterial;
        $this->hoseMaterial = $hoseMaterial;
        $this->coolantVolume = $coolantVolume;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `coolingSystem` (`name`, `radiatorMaterial`, `hoseMaterial`, `coolantVolume`) 
        VALUES ('$this->name', '$this->radiatorMaterial', '$this->hoseMaterial', '$this->coolantVolume')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `coolingSystem` WHERE `coolingSystem`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class BrakeSystem extends Autopart
{
    public $hydraulicVolume; //объем гидропривода
    public $countOfParkingBrakeClicks; //количество щелчков стояночного тормоза
    public $frontBrakes; //передние тормоза
    public $rearBrakes; //задние тормоза

    function __construct($name, $hydraulicVolume, $countOfParkingBrakeClicks, $frontBrakes, $rearBrakes)
    {
        $this->name = $name;
        $this->hydraulicVolume = $hydraulicVolume;
        $this->countOfParkingBrakeClicks = $countOfParkingBrakeClicks;
        $this->frontBrakes = $frontBrakes;
        $this->rearBrakes = $rearBrakes;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `brakeSystem` (`name`, `hydraulicVolume`, `countOfParkingBrakeClicks`, `frontBrakes`, `rearBrakes`) 
        VALUES ('$this->name', '$this->hydraulicVolume', '$this->countOfParkingBrakeClicks', '$this->frontBrakes', '$this->rearBrakes')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `brakeSystem` WHERE `brakeSystem`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class Electronics extends Autopart
{
    public $typeOfElectricalNetwork; //тип электрической сети
    public $batteryCapacity; //емкость аккумулятора
    public $batteryCurrentStrength; //сила тока аккумулятора
    public $generatorModel; //модель генератора
    public $generatorCurrentStrength; //сила тока генератора


    function __construct($name, $typeOfElectricalNetwork, $batteryCapacity, $batteryCurrentStrength, $generatorModel, $generatorCurrentStrength)
    {
        $this->name = $name;
        $this->typeOfElectricalNetwork = $typeOfElectricalNetwork;
        $this->batteryCapacity = $batteryCapacity;
        $this->batteryCurrentStrength = $batteryCurrentStrength;
        $this->generatorModel = $generatorModel;
        $this->generatorCurrentStrength = $generatorCurrentStrength;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `electronics` (`name`, `typeOfElectricalNetwork`, `batteryCapacity`, `batteryCurrentStrength`, `generatorModel`, `generatorCurrentStrength`) 
        VALUES ('$this->name', '$this->typeOfElectricalNetwork', '$this->batteryCapacity', '$this->batteryCurrentStrength', '$this->generatorModel', '$this->generatorCurrentStrength')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `electronics` WHERE `electronics`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class SteeringSystem extends Autopart
{
    public $freeSteering; //свободный ход рулевого колеса
    public $modelCompatibility; //совместимость с моделями


    function __construct($name, $freeSteering, $modelCompatibility)
    {
        $this->name = $name;
        $this->freeSteering = $freeSteering;
        $this->modelCompatibility = $modelCompatibility;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `steeringSystem` (`name`, `freeSteering`, `modelCompatibility`) 
        VALUES ('$this->name', '$this->freeSteering', '$this->modelCompatibility')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `steeringSystem` WHERE `steeringSystem`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class RunningSystem extends Autopart
{
    public $suspensionClassification; //классификация подвески
    public $typeOfFrontSuspension; //тип передней подвески
    public $typeOfRearSuspension; //тип задней подвески
    public $workingEnvironmentOfAbsorbers; //рабочая среда амортизаторов


    function __construct($name, $suspensionClassification, $typeOfFrontSuspension, $typeOfRearSuspension, $workingEnvironmentOfAbsorbers)
    {
        $this->name = $name;
        $this->suspensionClassification = $suspensionClassification;
        $this->typeOfFrontSuspension = $typeOfFrontSuspension;
        $this->typeOfRearSuspension = $typeOfRearSuspension;
        $this->workingEnvironmentOfAbsorbers = $workingEnvironmentOfAbsorbers;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `runningSystem` (`name`, `suspensionClassification`, `typeOfFrontSuspension`, `typeOfRearSuspension`, `workingEnvironmentOfAbsorbers`) 
        VALUES ('$this->name', '$this->suspensionClassification', '$this->typeOfFrontSuspension', '$this->typeOfRearSuspension', '$this->workingEnvironmentOfAbsorbers')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `runningSystem` WHERE `runningSystem`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class ReleaseSystem extends Autopart
{
    public $silencerMaterial; //материал глушителя
    public $typeOfExhaustManifold; //вид выпускного коллектора


    function __construct($name, $silencerMaterial, $typeOfExhaustManifold)
    {
        $this->name = $name;
        $this->silencerMaterial = $silencerMaterial;
        $this->typeOfExhaustManifold = $typeOfExhaustManifold;
    }

    function AddAutopart()
    {
        require("connection/connection.php");
        $addAutopart = "INSERT INTO `releaseSystem` (`name`, `silencerMaterial`, `typeOfExhaustManifold`) 
        VALUES ('$this->name', '$this->silencerMaterial', '$this->typeOfExhaustManifold')";
        $addAutopartQuery = $autoproConnection->query($addAutopart);
    }

    function DeleteAutopart($id)
    {
        require("connection/connection.php");
        $deleteAutopart = "DELETE FROM `releaseSystem` WHERE `releaseSystem`.id = '$id'";
        $deleteAutopartQuery = $autoproConnection->query($deleteAutopart);
    }
}

class Characteristics
{
    public $characteristicName; //Наименование комплектации
    public $producingCountry; //Страна производитель
    public $engineID; //ID двигателя
    public $transmissionID; //ID трансмиссии
    public $coolingSystemID; //ID системы охлаждения
    public $brakeSystemID; //ID тормозной системы
    public $electronicsID; //ID электрооборудования
    public $steeringSystemID; //ID рулевой системы
    public $runningSystemID; //ID ходовой системы
    public $releaseSystemID; //ID системы выпуска

    function __construct($characteristicName, $producingCountry, $engineID, $transmissionID, $coolingSystemID, $brakeSystemID, $electronicsID, $steeringSystemID, $runningSystemID, $releaseSystemID)
    {
        $this->characteristicName = $characteristicName;
        $this->producingCountry = $producingCountry;
        $this->engineID = $engineID;
        $this->transmissionID = $transmissionID;
        $this->coolingSystemID = $coolingSystemID;
        $this->brakeSystemID = $brakeSystemID;
        $this->electronicsID = $electronicsID;
        $this->steeringSystemID = $steeringSystemID;
        $this->runningSystemID = $runningSystemID;
        $this->releaseSystemID = $releaseSystemID;
    }

    function AddCharacteristics()
    {
        require("connection/connection.php");
        $addCharacteristics = "INSERT INTO `characteristics` (`name`, `producingCountry`, `id_engine`, `id_transmission`, `id_coolingSystem`, `id_brakeSystem`, `id_electronics`, `id_steeringSystem`, `id_runningSystem`, `id_releaseSystem`) 
        VALUES ('$this->characteristicName', '$this->producingCountry', '$this->engineID', '$this->transmissionID', '$this->coolingSystemID', '$this->brakeSystemID', '$this->electronicsID', '$this->steeringSystemID', '$this->runningSystemID', '$this->releaseSystemID')";
        $addCharacteristicsQuery = $autoproConnection->query($addCharacteristics);
    }

    function DeleteCharacteristics($id)
    {
        require("connection/connection.php");
        $deleteCharacteristics = "DELETE FROM `characteristics` WHERE `characteristics`.id = '$id'";
        $deleteCharacteristicsQuery = $autoproConnection->query($deleteCharacteristics);
    }

    function UpdateCharacteristics($id, $name, $country, $engine, $transmission, $coolingSystem, $brakeSystem, $electronics, $steeringSystem, $runningSystem, $releaseSystem)
    {
        require("connection/connection.php");
        $updateCharacteristics = "UPDATE `characteristics` SET `name` = '$name', `producingCountry` = '$country', `id_engine` = '$engine', `id_transmission` = '$transmission', `id_coolingSystem` = '$coolingSystem', `id_brakeSystem` = '$brakeSystem', `id_electronics` = '$electronics', `id_steeringSystem` = '$steeringSystem', `id_runningSystem` = '$runningSystem', `id_releaseSystem` = '$releaseSystem'
        WHERE `characteristics`.id = '$id'";
        $updateCharacteristicsQuery = $autoproConnection->query($updateCharacteristics);
    }
}

class Client
{
    public $name; //Имя
    public $surname; //Фамилия
    public $middleName; //Отчество
    public $birthdate; //Дата рождения
    public $gender; //Пол
    public $passport; //Паспорт
    public $phoneNumber; //Номер телефона

    function __construct($name, $surname, $middleName, $birthdate, $gender, $passport, $phoneNumber)
    {
        $this->name = $name;
        $this->surname = $surname;
        $this->middleName = $middleName;
        $this->birthdate = $birthdate;
        $this->gender = $gender;
        $this->passport = $passport;
        $this->phoneNumber = $phoneNumber;
    }

    function AddClient()
    {
        require("connection/connection.php");
        $addClient = "INSERT INTO `client` (`name`, `surname`, `middleName`, `birthdate`, `gender`, `passport`, `phone`) 
        VALUES ('$this->name', '$this->surname', '$this->middleName', '$this->birthdate', '$this->gender', '$this->passport', '$this->phoneNumber')";
        $addClientQuery = $autoproConnection->query($addClient);
    }

    function DeleteClient($id)
    {
        require("connection/connection.php");
        $deleteClient = "DELETE FROM `client` WHERE `client`.id = '$id'";
        $deleteClientQuery = $autoproConnection->query($deleteClient);
    }

    function UpdateClient($id, $name, $surname, $middleName, $birthdate, $gender, $passport, $phoneNumber)
    {
        require("connection/connection.php");
        $updateClient = "UPDATE `client` SET `name` = '$name', `surname` = '$surname', `middleName` = '$middleName', `birthdate` = '$birthdate', `gender` = '$gender', `passport` = '$passport', `phone` = '$phoneNumber'
        WHERE `client`.id = '$id'";
        $updateClientQuery = $autoproConnection->query($updateClient);
    }
}

class Car
{
    public $carBrand; //Марка автомобиля
    public $carModel; //Модель автомобиля
    public $carYearOfRelease; //Год выпуска автомобиля
    public $carStateNumber; //Государственный номер автомобиля
    public $clientID; //ID клиента
    public $characteristicID; //ID комплектации автомобиля

    function __construct($carBrand, $carModel, $carYearOfRelease, $carStateNumber, $clientID, $characteristicID)
    {
        $this->carBrand = $carBrand;
        $this->carModel = $carModel;
        $this->carYearOfRelease = $carYearOfRelease;
        $this->carStateNumber = $carStateNumber;
        $this->clientID = $clientID;
        $this->characteristicID = $characteristicID;
    }

    function AddCar()
    {
        require("connection/connection.php");
        $addCar = "INSERT INTO `car` (`carBrand`, `carModel`, `carYearOfRelease`, `carStateNumber`, `id_client`, `id_characteristic`)
        VALUES ('$this->carBrand', '$this->carModel', '$this->carYearOfRelease', '$this->carStateNumber', '$this->clientID', '$this->characteristicID')";
        $addCarQuery = $autoproConnection->query($addCar);
    }

    function DeleteCar($id)
    {
        require("connection/connection.php");
        $deleteCar = "DELETE FROM `car` WHERE `car`.id = '$id'";
        $deleteCarQuery = $autoproConnection->query($deleteCar);
    }

    function UpdateCar($id, $carBrand, $carModel, $carYearOfRelease, $carStateNumber, $clientID, $characteristicID)
    {
        require("connection/connection.php");
        $updateCar = "UPDATE `car` SET `carBrand` = '$carBrand', `carModel` = '$carModel', `carYearOfRelease` = '$carYearOfRelease', `carStateNumber` = '$carStateNumber', `id_client` = '$clientID', `id_characteristic` = '$characteristicID'
        WHERE `car`.id = '$id'";
        $updateCarQuery = $autoproConnection->query($updateCar);
    }
}

class Master
{
    public $masterName; //Имя мастера
    public $masterSurname; //Фамилия мастера
    public $masterMiddleName; //Отчество мастера
    public $workExperience; //Стаж работы мастера
    public $masterPhoneNumber; //Номер телефона мастера

    function __construct($masterName, $masterSurname, $masterMiddleName, $workExperience, $masterPhoneNumber)
    {
        $this->masterName = $masterName;
        $this->masterSurname = $masterSurname;
        $this->masterMiddleName = $masterMiddleName;
        $this->workExperience = $workExperience;
        $this->masterPhoneNumber = $masterPhoneNumber;
    }

    function AddMaster()
    {
        require("connection/connection.php");
        $addMaster = "INSERT INTO `master` (`name`, `surname`, `middleName`, `workExperience`, `phone`, `status`)
        VALUES ('$this->masterName', '$this->masterSurname', '$this->masterMiddleName', '$this->workExperience', '$this->masterPhoneNumber', 'Свободен')";
        $addMasterQuery = $autoproConnection->query($addMaster);
    }

    function DeleteMaster($id)
    {
        require("connection/connection.php");
        $deleteMaster = "DELETE FROM `master` WHERE `master`.id = '$id'";
        $deleteMasterQuery = $autoproConnection->query($deleteMaster);
    }

    function UpdateMaster($id, $masterName, $masterSurname, $masterMiddleName, $workExperience, $masterPhoneNumber)
    {
        require("connection/connection.php");
        $updateMaster = "UPDATE `master` SET `name` = '$masterName', `surname` = '$masterSurname', `middleName` = '$masterMiddleName', `workExperience` = '$workExperience', `phone` = '$masterPhoneNumber', `status` = 'Свободен'
        WHERE `master`.id = '$id'";
        $updateMasterQuery = $autoproConnection->query($updateMaster);
    }
}

class Contract
{
    public $contractDate;

    function __construct()
    {
        require("connection/connection.php");
        $selectCurrentDate = "SELECT CURRENT_DATE()";
        $currentDate = $autoproConnection->query($selectCurrentDate);
        $this->contractDate = $currentDate->fetch_array();
    }

    function CreateContract($clientID, $masterID, $repairID)
    {
        require("connection/connection.php");
        $contractDate = $this->contractDate;
        $selectTotalPriceOfRepair = "SELECT `carrepair`.`TotalPriceOfServices` FROM `carrepair` WHERE `carrepair`.`id` = '$repairID'";
        $selectTotalPriceOfRepairQuery = $autoproConnection->query($selectTotalPriceOfRepair);
        $totalPriceOfRepair = $selectTotalPriceOfRepairQuery->fetch_array();

        $contractCreate = "INSERT INTO `contract`(`contractDate`, `contractStatus`, `totalPrice`, `client_id`, `master_id`, `repair_id`)
        VALUES ('$contractDate[0]', 'Выполняется', '$totalPriceOfRepair[0]', '$clientID', '$masterID', '$repairID')";
        $contractCreateQuery = $autoproConnection->query($contractCreate);        
        $updateMasterStatus = "UPDATE `master` SET `status` = 'Занят' WHERE `master`.id = '$masterID'";
        $updateMasterStatusQuery = $autoproConnection->query($updateMasterStatus);
    }

    function IncludeRecommendationOnContract($clientID, $masterID, $repairID)
    {
        require("connection/connection.php");
        $contractDate = $this->contractDate;
        $selectTotalPriceOfRepair = "SELECT `carrepair`.`TotalPriceOfServices`, `carrepair`.`TotalPriceOfRecommendations` FROM `carrepair` WHERE `carrepair`.`id` = '$repairID'";
        $selectTotalPriceOfRepairQuery = $autoproConnection->query($selectTotalPriceOfRepair);
        $totalPriceOfRepair = $selectTotalPriceOfRepairQuery->fetch_array();
        $totalPrice = $totalPriceOfRepair[0] + $totalPriceOfRepair[1];

        $contractCreate = "INSERT INTO `contract`(`contractDate`, `contractStatus`, `totalPrice`, `client_id`, `master_id`, `repair_id`)
        VALUES ('$contractDate[0]', 'Выполняется', '$totalPrice', '$clientID', '$masterID', '$repairID')";
        $contractCreateQuery = $autoproConnection->query($contractCreate);        
        $updateMasterStatus = "UPDATE `master` SET `status` = 'Занят' WHERE `master`.id = '$masterID'";
        $updateMasterStatusQuery = $autoproConnection->query($updateMasterStatus);
    }

    function FinishContract($contractID)
    {
        require("connection/connection.php");
        $finishContract = "UPDATE `contract` SET `contractStatus` = 'Завершен' WHERE `contract`.id = '$contractID'";
        $finishContractQuery = $autoproConnection->query($finishContract);

        $selectMasterFromContract = "SELECT `contract`.master_id FROM `contract`
        WHERE `contract`.id = '$contractID'";
        $selectMasterFromContractQuery = $autoproConnection->query($selectMasterFromContract);
        $masterFromContract = $selectMasterFromContractQuery->fetch_array();

        $updateMasterStatus = "UPDATE `master` SET `status` = 'Свободен' WHERE `master`.id = '$masterFromContract[0]'";
        $updateMasterStatusQuery = $autoproConnection->query($updateMasterStatus);
    }
}