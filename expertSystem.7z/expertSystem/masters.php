<?php
    if(isset($_POST['addMasterButton']))
    {
        $masterName = $_POST['masterName'];
        $masterSurname = $_POST['masterSurname'];
        $masterMiddleName = $_POST['masterMiddleName'];
        $workExperience = $_POST['workExperience'];
        $masterPhone = $_POST['masterPhone'];

        if(!empty($masterName) && !empty($masterSurname) && !empty($masterMiddleName) && !is_int($workExperience) && !empty($masterPhone))
        {
            require("autoPRO.php");
            $master = new Master($masterName, $masterSurname, $masterMiddleName, $workExperience, $masterPhone);
            $master->AddMaster();
            header("Location: http://expertsystem/masters.php");
        }
    }
    if(isset($_POST['updateMasterButton']))
    {
        $masterID = $_POST['masterID'];
        $masterName = $_POST['masterName'];
        $masterSurname = $_POST['masterSurname'];
        $masterMiddleName = $_POST['masterMiddleName'];
        $workExperience = $_POST['workExperience'];
        $masterPhone = $_POST['masterPhone'];

        if(!empty($masterName) && !empty($masterSurname) && !empty($masterMiddleName) && !is_int($workExperience) && !empty($masterPhone))
        {
            require("autoPRO.php");
            $master = new Master($masterName, $masterSurname, $masterMiddleName, $workExperience, $masterPhone);
            $master->UpdateMaster($masterID, $masterName, $masterSurname, $masterMiddleName, $workExperience, $masterPhone);
            header("Location: http://expertsystem/masters.php");
        }
    }
    if(isset($_POST['deleteMasterButton']))
    {
        $masterID = $_POST['masterID'];
        $masterName = $_POST['masterName'];
        $masterSurname = $_POST['masterSurname'];
        $masterMiddleName = $_POST['masterMiddleName'];
        $workExperience = $_POST['workExperience'];
        $masterPhone = $_POST['masterPhone'];

        require("autoPRO.php");
        $master = new Master($masterName, $masterSurname, $masterMiddleName, $workExperience, $masterPhone);
        $master->DeleteMaster($masterID);
        header("Location: http://expertsystem/masters.php");
    }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> База сотрудников </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="title">
    <div class="subtitle_first"> Сотрудники </div>
</div>

<div class="masters">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Имя мастера</th>
        <th>Фамилия мастера</th>
        <th>Отчество мастера</th>
        <th>Стаж работы</th>
        <th>Телефон</th>
        <th>Занятость</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutMaster = "SELECT * FROM `master`";
        $selectInformationAboutMasterQuery = $autoproConnection->query($selectInformationAboutMaster);
        while($info = $selectInformationAboutMasterQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
                <td><?php echo $info[6]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление сотрудника </div>

    <form class="operation_form" name="addMasterForm" method="post">
        <div class="addMaster">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите имя мастера: </div>
                <textarea class="textareaClass" name="masterName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите фамилию мастера: </div>
                <textarea class="textareaClass" name="masterSurname"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите отчество мастера: </div>
                <textarea class="textareaClass" name="masterMiddleName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите стаж работы: </div>
                <textarea class="textareaClass" name="workExperience"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите номер телефона мастера: </div>
                <textarea class="textareaClass" name="masterPhone"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addMasterButton" value="Добавить мастера"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Изменение мастера </div>

    <form class="operation_form" name="updateMasterForm" method="post">
        <div class="updateMaster">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID мастера: </div>
                <select class="selectClass" name="masterID">
                <?php require("connection/connection.php");
                $selectMasterID = "SELECT `master`.id FROM `master`";
                $selectMasterIDQuery = $autoproConnection->query($selectMasterID);
                while($masterID = $selectMasterIDQuery->fetch_array())
                {?>
                    <option><?php echo $masterID['id']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите имя мастера: </div>
                <textarea class="textareaClass" name="masterName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите фамилию мастера: </div>
                <textarea class="textareaClass" name="masterSurname"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите отчество мастера: </div>
                <textarea class="textareaClass" name="masterMiddleName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите стаж работы: </div>
                <textarea class="textareaClass" name="workExperience"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите номер телефона мастера: </div>
                <textarea class="textareaClass" name="masterPhone"></textarea>
            </div>

            <input class="submitButton" type="submit" name="updateMasterButton" value="Изменить мастера"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление мастера </div>

    <form class="operation_form" name="deleteMasterForm" method="post">
        <div class="deleteMaster">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID мастера: </div>
                <select class="selectClass" name="masterID">
                <?php require("connection/connection.php");
                $selectMasterID = "SELECT `master`.id FROM `master`";
                $selectMasterIDQuery = $autoproConnection->query($selectMasterID);
                while($masterID = $selectMasterIDQuery->fetch_array())
                {?>
                    <option><?php echo $masterID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteMasterButton" value="Удалить мастера"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 