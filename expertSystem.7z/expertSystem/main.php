<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> AutoPro </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="main">
    <div class="main_banner">
        <img src="images/information.jpg" width="1400px" height="400px">
    </div>
</div>

<div class="getStart">
    <div class="getStartButton"> <a href="http://expertsystem/diagnostic.php">Начать работу </a> </div>
</div>

<div class="info">
    <div class="info_items">
        <div class="info_item"> <img src="images/banner1.jpg" width="300px" height="300px"> </div>
        <div class="info_item"> <img src="images/banner2.jpg" width="300px" height="300px"> </div>
        <div class="info_item"> <img src="images/banner3.jpg" width="300px" height="300px"> </div>
        <div class="info_item"> <img src="images/banner4.jpg" width="300px" height="300px"> </div>
    </div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 