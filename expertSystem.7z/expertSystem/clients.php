<?php
    if(isset($_POST['addClientButton']))
    {
        $clientName = $_POST['clientName'];
        $clientSurname = $_POST['clientSurname'];
        $clientMiddleName = $_POST['clientMiddleName'];
        $clientBirthdate = $_POST['clientBirthdate'];
        $clientGender = $_POST['clientGender'];
        $clientPassport = $_POST['clientPassport'];
        $clientPhone = $_POST['clientPhone'];
        if(!empty($clientName) && !empty($clientSurname) && !empty($clientMiddleName) && !empty($clientBirthdate)
        && !empty($clientGender) && !empty($clientPassport) && !empty($clientPhone))
        {
            require("autoPRO.php");
            $client = new Client($clientName, $clientSurname, $clientMiddleName, $clientBirthdate, $clientGender, $clientPassport, $clientPhone);
            $client->AddClient();
            header("Location: http://expertsystem/clients.php");
        }
    }
    if(isset($_POST['updateClientButton']))
    {
        $clientID = $_POST['clientID'];
        $clientName = $_POST['clientName'];
        $clientSurname = $_POST['clientSurname'];
        $clientMiddleName = $_POST['clientMiddleName'];
        $clientBirthdate = $_POST['clientBirthdate'];
        $clientGender = $_POST['clientGender'];
        $clientPassport = $_POST['clientPassport'];
        $clientPhone = $_POST['clientPhone'];
        if(!empty($clientID) && !empty($clientName) && !empty($clientSurname) && !empty($clientMiddleName) && !empty($clientBirthdate)
        && !empty($clientGender) && !empty($clientPassport) && !empty($clientPhone))
        {
            require("autoPRO.php");
            $client = new Client($clientName, $clientSurname, $clientMiddleName, $clientBirthdate, $clientGender, $clientPassport, $clientPhone);
            $client->UpdateClient($clientID, $clientName, $clientSurname, $clientMiddleName, $clientBirthdate, $clientGender, $clientPassport, $clientPhone);
            header("Location: http://expertsystem/clients.php");
        }
    }
    if(isset($_POST['deleteClientButton']))
    {
        $clientID = $_POST['clientID'];
        $clientName = $_POST['clientName'];
        $clientSurname = $_POST['clientSurname'];
        $clientMiddleName = $_POST['clientMiddleName'];
        $clientBirthdate = $_POST['clientBirthdate'];
        $clientGender = $_POST['clientGender'];
        $clientPassport = $_POST['clientPassport'];
        $clientPhone = $_POST['clientPhone'];

        require("autoPRO.php");
        $client = new Client($clientName, $clientSurname, $clientMiddleName, $clientBirthdate, $clientGender, $clientPassport, $clientPhone);
        $client->DeleteClient($clientID);
        header("Location: http://expertsystem/clients.php");
    }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> База клиентов </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="title">
    <div class="subtitle_first"> Клиенты </div>
</div>

<div class="clients">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Имя клиента</th>
        <th>Фамилия клиента</th>
        <th>Отчество клиента</th>
        <th>Дата рождения</th>
        <th>Пол</th>
        <th>Паспорт</th>
        <th>Телефон</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutClient = "SELECT * FROM `client`";
        $selectInformationAboutClientQuery = $autoproConnection->query($selectInformationAboutClient);
        while($info = $selectInformationAboutClientQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
                <td><?php echo $info[6]; ?></td>
                <td><?php echo $info[7]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление клиента </div>

    <form class="operation_form" name="addClientForm" method="post">
        <div class="addClient">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите имя клиента: </div>
                <textarea class="textareaClass" name="clientName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите фамилию клиента: </div>
                <textarea class="textareaClass" name="clientSurname"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите отчество клиента: </div>
                <textarea class="textareaClass" name="clientMiddleName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите дату рождения (ГГГГ-ММ-ДД): </div>
                <textarea class="textareaClass" name="clientBirthdate"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите пол: </div>
                <select class="selectClass" name="clientGender">
                    <option> Мужской </option>
                    <option> Женский </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите паспорт: </div>
                <textarea class="textareaClass" name="clientPassport"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите номер телефона: </div>
                <textarea class="textareaClass" name="clientPhone"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addClientButton" value="Добавить клиента"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Изменение клиента </div>

    <form class="operation_form" name="updateClientForm" method="post">
        <div class="updateClient">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID клиента: </div>
                <select class="selectClass" name="clientID">
                <?php require("connection/connection.php");
                $selectClientID = "SELECT `client`.id FROM `client`";
                $selectClientIDQuery = $autoproConnection->query($selectClientID);
                while($clientID = $selectClientIDQuery->fetch_array())
                {?>
                    <option><?php echo $clientID['id']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите имя клиента: </div>
                <textarea class="textareaClass" name="clientName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите фамилию клиента: </div>
                <textarea class="textareaClass" name="clientSurname"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите отчество клиента: </div>
                <textarea class="textareaClass" name="clientMiddleName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите дату рождения (ГГГГ-ММ-ДД): </div>
                <textarea class="textareaClass" name="clientBirthdate"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите пол: </div>
                <select class="selectClass" name="clientGender">
                    <option> Мужской </option>
                    <option> Женский </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите паспорт: </div>
                <textarea class="textareaClass" name="clientPassport"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите номер телефона: </div>
                <textarea class="textareaClass" name="clientPhone"></textarea>
            </div>

            <input class="submitButton" type="submit" name="updateClientButton" value="Изменить клиента"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление клиента </div>

    <form class="operation_form" name="deleteClientForm" method="post">
        <div class="deleteClient">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID клиента: </div>
                <select class="selectClass" name="clientID">
                <?php require("connection/connection.php");
                $selectClientID = "SELECT `client`.id FROM `client`";
                $selectClientIDQuery = $autoproConnection->query($selectClientID);
                while($clientID = $selectClientIDQuery->fetch_array())
                {?>
                    <option><?php echo $clientID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteClientButton" value="Удалить клиента"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 