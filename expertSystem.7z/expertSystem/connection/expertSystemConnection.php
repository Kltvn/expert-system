<?php
    $localhost = "localhost";
    $db = "expertsystem";
    $user = "admin";
    $password = "admin";
    
    $expertSystemConnection = new mysqli($localhost, $user, $password, $db);
    
    mysqli_query($expertSystemConnection, "SET NAMES UTF-8;");
    mysqli_query($expertSystemConnection, "SET CHARACTER SET UTF-8;");
?>