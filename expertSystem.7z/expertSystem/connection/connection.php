<?php
    $localhost = "localhost";
    $db = "autoproexpert";
    $user = "admin";
    $password = "admin";
    
    $autoproConnection = new mysqli($localhost, $user, $password, $db);
    
    mysqli_query($autoproConnection, "SET NAMES UTF-8;");
    mysqli_query($autoproConnection, "SET CHARACTER SET UTF-8;");
?>