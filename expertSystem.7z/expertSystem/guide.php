<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> О программе </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="guide">
    <div class="instruction">
        <div class="title">
            <div class="subtitle_first"> Нажмите на кнопку "НАЧАТЬ" </div>
        </div>
        <div class="guide_photo">
            <img src="images/12.png" width="1920" height="1015">
        </div>
    </div>

    <div class="instruction">
        <div class="title">
            <div class="subtitle_first"> Отвечайте на вопросы </div>
        </div>
        <div class="guide_photo">
            <img src="images/13.png" width="1920" height="1015">
        </div>
    </div>

    <div class="instruction">
        <div class="title">
            <div class="subtitle_first"> После нажмите на "Выполнить" </div>
        </div>
        <div class="guide_photo">
            <img src="images/14.png" width="1920" height="555">
        </div>
    </div>

    <div class="instruction">
        <div class="title">
            <div class="subtitle_first"> Результат диагностики появится на вашем экране </div>
        </div>
        <div class="guide_photo">
            <img src="images/15.png" width="1920" height="1070">
        </div>
    </div>

    <div class="instruction">
        <div class="title">
            <div class="subtitle_first"> Выберите клиента, мастера и по желанию поставьте галочку </div>
        </div>
        <div class="guide_photo">
            <img src="images/16.png" width="600" height="380">
        </div>
    </div>

    <div class="instruction">
        <div class="title">
            <div class="subtitle_first"> Готово! Вы создали заказ </div>
        </div>
        <div class="guide_photo">
            <img src="images/17.png" width="1920" height="1080">
        </div>
    </div>
</div>

<div class="title">
    <div class="subtitle_first"> Спасибо, что вы с нами! </div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 