<?php
    if(isset($_POST['finalContractButton']))
    {
        require("connection/connection.php");
        $contractID = $_POST['contractList'];
        $selectContractStatus = "SELECT `contract`.contractStatus FROM `contract` WHERE `contract`.id = '$contractID'";
        $selectContractStatusQuery = $autoproConnection->query($selectContractStatus);
        $contractStatus = $selectContractStatusQuery->fetch_array();

        if($contractStatus[0] == 'Выполняется')
        {
            require("autoPRO.php");
            $autoPRO = new Contract();
            $autoPRO->FinishContract($contractID);
            header("Location: http://expertsystem/contracts.php");
        }
    }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> Заказы </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="title">
    <div class="subtitle_first"> Заказы </div>
</div>

<div class="contracts">
<div class="order">
    <div class="contracts_table">
    <table>

    <tr>
        <th>№</th>
        <th>Дата</th>
        <th>ФИО клиента</th>
        <th>ТС</th>
        <th>ФИО мастера</th>
        <th>Услуги</th>
        <th>Рекомендации</th>
        <th>Стоимость</th>
        <th>Статус заказа</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutContract = "SELECT `contract`.id, `contract`.`contractDate`, `client`.`Name`, `client`.`Surname`, `client`.`Middlename`, `car`.`CarBrand`, `car`.`CarModel`, `master`.`Name`, `master`.`Surname`, `master`.`Middlename`, `carrepair`.`used_service`, `carrepair`.`used_recommendation`, `contract`.`TotalPrice`, `contract`.`contractStatus` FROM `contract`, `client`, `car`, `carrepair`, `master`
        WHERE `client`.`id` = `contract`.`client_id` AND `car`.`id_client` = `contract`.`client_id` AND `master`.`id` = `contract`.`master_id` AND `carrepair`.`id` = `contract`.`repair_id`";
        $selectInformationAboutContractQuery = $autoproConnection->query($selectInformationAboutContract);
        while($info = $selectInformationAboutContractQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2], " ", $info[3], " ", $info[4]; ?></td>
                <td><?php echo $info[5], " ", $info[6]; ?></td>
                <td><?php echo $info[7], " ", $info[8], " ", $info[9]; ?></td>
                <td><?php echo $info[10]; ?></td>
                <td><?php echo $info[11]; ?></td>
                <td><?php echo $info[12]; ?></td>
                <td><?php echo $info[13]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Управление заказами </div>

    <form class="select_contract_form" name="contractForm" method="post">
        <div class="selectContract">
            <div class="subtitle_second"> Выберите ID заказа: </div>
            <select class="contract_list" name="contractList">
            <?php require("connection/connection.php");
                $selectContracts = "SELECT `contract`.id FROM `contract`";
                $selectContractsQuery = $autoproConnection->query($selectContracts);
                while($contract = $selectContractsQuery->fetch_array())
                {?>
                    <option><?php echo $contract['id']; ?></option> <?php
                }           
	            ?>
            </select> 

            <input class="finalContract" type="submit" name="finalContractButton" value="Завершить заказ"> </input>
        </div>
    </form>
</div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 