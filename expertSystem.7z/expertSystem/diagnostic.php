<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> Диагностика </title>
</head>

<body>
<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="title">
    <div class="subtitle_first"> Комплексная диагностика </div>
</div>

<div class="complex_diagnostic">
    <?php 
        require("connection/expertSystemConnection.php");
        require("expert.php");
        $expertSystem = new ExpertSystem();
        $selectQuestionsCount = "SELECT DISTINCT `variable`.id, `variable`.`Question` FROM `fact`, `variable` WHERE `variable`.`id` = `fact`.`variable_id` AND `variable`.`Question` != '' ";
        $selectQuestionsCountQuery = $expertSystemConnection->query($selectQuestionsCount);
        $countQuestion = 5;
        $countRows = $selectQuestionsCountQuery->num_rows; 

        if(isset($_GET['page']))
        {
            $pageNum = (int)$_GET['page'];
        }else
        {
            $pageNum = 1;
        }
        $startIndex = ($pageNum-1)*$countQuestion;

        $selectQuestions = "SELECT DISTINCT `variable`.id, `variable`.`Question` FROM `fact`, `variable`
        WHERE `variable`.`id` = `fact`.`variable_id` AND `variable`.`Question` != '' LIMIT $startIndex, $countQuestion";
        $selectQuestionsQuery = $expertSystemConnection->query($selectQuestions); 
        while($question = $selectQuestionsQuery->fetch_array())
        {?>
        <div class="questions">
            <form class="question-form" name="factQuestion" method="post">
                <div class="question-title">
                    <input type="text" name="title" id="title" value="<?php echo $question[1];?>"/>
                </div>
                <input type="hidden" name="factID" value="<?php echo $question[0]?>" />
                <input class="question-button" type="submit" name="yesButton" value="Да"></input>
                <input class="question-button" type="submit" name="noButton" value="Нет"></input>
            </form>
        <?php    
        } ?>
        </div>   
        <ul class="pagination">
            <?php
                $countOfPagination = ceil($countRows / $countQuestion);
                for($i=1; $i<=$countOfPagination; $i++)
                {?>
                    <li> <a <? if($i == $pageNum) echo 'class="active"';?> href="diagnostic.php?page=<?echo $i;?>"> <?php echo $i?> </a></li> <?php
                }
            ?>
        </ul>  
    <?php
    if($pageNum == $countOfPagination)
    {
        require("connection/connection.php");
        $selectOrderID = "SELECT `carrepair`.id FROM `carrepair` ORDER BY id DESC LIMIT 1";
        $selectOrderIDQuery = $autoproConnection->query($selectOrderID);
        $orderID = $selectOrderIDQuery->fetch_array(); ?>
    <div class="goExpert"> <a href="order.php?order=<?php echo $orderID[0] + 1; ?>"> Выполнить </a> </div>
    <?php
    }?>
</div>

<?php
if(isset($_POST['yesButton']))
{
    $expertSystem->CheckingFactOfTruth($_POST['factID'], 'Да');
}

if(isset($_POST['noButton']))
{
    $expertSystem->CheckingFactOfTruth($_POST['factID'], 'Нет');
}
?>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 