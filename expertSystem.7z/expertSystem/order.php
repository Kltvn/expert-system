<?php
    require("expert.php");
    $orderID = $_GET['order'];
    $expertSystem = new ExpertSystem();
    $expertSystem->SearchForWorkingRules();

    if(isset($_POST['createContractButton']))
    {
        require("autoPRO.php");
        $autoPRO = new Contract();
        $clientID = $_POST['clientsList'];
        $masterID = $_POST['mastersList'];
        if(isset($_POST['includeRec']))
        {
            if($masterID != "")
            {
                $autoPRO->IncludeRecommendationOnContract($clientID[0], $masterID[0], $orderID);
            }            
        }
        else
        {
            if($masterID != "")
            {
                $autoPRO->CreateContract($clientID[0], $masterID[0], $orderID);
            }
        }
        header("Location: http://expertsystem/contracts.php");
    }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> Заказ-наряд </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="title">
    <div class="subtitle_first"> Результат диагностики </div>
</div>

<div class="order">
    <div class="result-explanation">
        <?php
            foreach($expertSystem->explanations as $exp)
            {
                echo "$exp <br>";
            }
        require("connection/connection.php");
        $selectParametrs = "SELECT `client`.name, `client`.`Surname`, `client`.`Middlename`, `car`.`CarBrand`, `car`.`CarModel`, `car`.`CarStateNumber` FROM `client`, `car` 
        WHERE `client`.`id` = '$clientID' AND `car`.`id_client` = `client`.id;";
        $selectParametrsQuery = $autoproConnection->query($selectParametrs);
        $parametrs = $selectParametrsQuery->fetch_array();
        ?>
    <div class="order_information">
        <?php 
            $selectInformationAboutRepair = "SELECT * FROM `carrepair` WHERE `carrepair`.id = '$orderID'";
            $selectInformationAboutRepairQuery = $autoproConnection->query($selectInformationAboutRepair);
            $informationAboutRepair = $selectInformationAboutRepairQuery->fetch_array();
        ?>
        <br>
        Неисправности: <?php echo $informationAboutRepair[1], "<br>"; ?>
        Стоимость ремонта: <?php echo $informationAboutRepair[3]," руб.", "<br>"; ?>
        <br>
        Рекомендации по ремонту: <?php echo $informationAboutRepair[2], "<br>"; ?>
        Стоимость рекомендаций: <?php echo $informationAboutRepair[4]," руб.", "<br>"; ?>
    </div>
    </div>
</div>

<div class="title">
    <div class="subtitle_first"> Заказ </div>
</div>

<div class="newOrder">
<div class="order">
    <div class="selectClientAndMaster">
        <form class="select_clientMaster_form" name="clientAndMasterForm" method="post">
        <div class="selectClient">
            <div class="subtitle_second"> Выберите клиента: </div>
            <select class="clients_list" name="clientsList">
            <?php require("connection/connection.php");
                $selectClients = "SELECT `client`.id, `client`.name, `client`.surname FROM `client`";
                $selectClientsQuery = $autoproConnection->query($selectClients);
                while($client = $selectClientsQuery->fetch_array())
                {?>
                    <option><?php echo $client['id'], " - ", $client['name'], " ", $client['surname']; ?></option> <?php
                }           
	            ?>
            </select> 
        </div>
        
        <div class="selectMaster">
            <div class="subtitle_second"> Выберите мастера: </div>
            <select class="masters_list" name="mastersList">
            <?php require("connection/connection.php");
                $selectMasters = "SELECT `master`.id, `master`.name, `master`.surname FROM `master` WHERE `master`.status = 'Свободен'";
                $selectMastersQuery = $autoproConnection->query($selectMasters);
                while($master = $selectMastersQuery->fetch_array())
                {?>
                    <option><?php echo $master['id'], " - ", $master['name'], " ", $master['surname']; ?></option> <?php
                }           
	            ?>
            </select> 
        </div>  
        <div class="includeRecommendations">
            <div class="subtitle_second"> Включить рекомендации в ремонт? </div>
            <input class="includeRec" type="checkbox" name="includeRec" value="Включить"> </input>
        </div>  

        <div class="selectClientAndMasterButton">
            <input class="createContract" type="submit" name="createContractButton" value="Добавить контракт"> </input>
        </div>
        </form>
    </div> 
</div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 