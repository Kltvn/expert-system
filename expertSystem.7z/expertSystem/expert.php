<?php
class Variable
{
    public $allVariables;

    function __construct()
    {
        require("connection/expertSystemConnection.php");
        $selectVariables = "SELECT `variable`.id, `variable`.name from `variable` ORDER BY `variable`.id";
        $this->allVariables = $expertSystemConnection->query($selectVariables);       
    }

    function AddNewVariable($name, $type, $question)
    {
        if($type == 'Вводимая')
        {
            require("connection/expertSystemConnection.php");
            $addVariable = "INSERT INTO `variable` (`name`, `type`, `question`) VALUES ('$name', '$type', '$question')";
            $addVariableQuery = $expertSystemConnection->query($addVariable);
        }
        else
        {
            require("connection/expertSystemConnection.php");
            $addVariable = "INSERT INTO `variable` (`name`, `type`, `question`) VALUES ('$name', 'Выводимая', NULL)";
            $addVariableQuery = $expertSystemConnection->query($addVariable);
        }
    }
}

class Domain
{
    public $allDomains;

    function __construct()
    {
        require("connection/expertSystemConnection.php");
        $selectDomains = "SELECT * from domain ORDER BY `domain`.id";
        $this->allDomains = $expertSystemConnection->query($selectDomains); 
    }

    function AddNewDomain($name, $value, $price)
    {
        require("connection/expertSystemConnection.php");
        $addDomain = "INSERT INTO `domain` (`Name`, `Value`) VALUES ('$name', '$value')";
        $addDomainQuery = $expertSystemConnection->query($addDomain);

        require("connection/connection.php");
        if($name == 'Услуга')
        {
            $addService = "INSERT INTO `service` (`ServiceName`, `ServicePrice`) VALUES ('$name', $price)";
            $addServiceQuery = $autoproConnection->query($addService);
        }
        if($name == 'Рекомендация')
        {
            $addRecommendation = "INSERT INTO `recommendations` (`RecommendationsName`, `RecommendationsPrice`) VALUES ('$value', $price)";
            $addRecommendationQuery = $autoproConnection->query($addRecommendation);
        }
    }

    function RemoveDomain($value)
    {
        require("connection/expertSystemConnection.php");
        $findNameOfDeletedDomain = "SELECT `domain`.name from `domain` WHERE `domain`.value = '$value'";
        $findNameOfDeletedDomainQuery = $expertSystemConnection->query($findNameOfDeletedDomain);
        $nameOfDeletedDomain = $findNameOfDeletedDomainQuery->fetch_array();

        $deleteDomain = "DELETE FROM `domain` WHERE `domain`.value = '$value'";
        $deleteDomainQuery = $expertSystemConnection->query($deleteDomain);
       
        require("connection/connection.php");
        if($nameOfDeletedDomain[0] == 'Услуга')
        {
            $deleteService = "DELETE FROM `service` WHERE `service`.ServiceName = '$value'";
            $deleteServiceQuery = $autoproConnection->query($deleteService);
        }
        if($nameOfDeletedDomain[0] == 'Рекомендация')
        {
            $deleteRecommendation = "DELETE FROM `recommendations` WHERE `recommendations`.RecommendationsName = '$value'";
            $deleteRecommendationQuery = $autoproConnection->query($deleteRecommendation);
        }        
    }
}

class Fact
{
    public $allFacts;

    function __construct()
    {
        require("connection/expertSystemConnection.php");
        $selectFacts = "SELECT * from `fact` ORDER BY `fact`.id";
        $this->allFacts = $expertSystemConnection->query($selectFacts); 
    }

    function AddNewFact($variable_id, $domain_id, $annotation)
    {
        require("connection/expertSystemConnection.php");
        $addFact = "INSERT INTO `fact` (`variable_id`, `domain_id`, `annotation`) VALUES ('$variable_id', '$domain_id', '$annotation')";
        $addFactQuery = $expertSystemConnection->query($addFact);
    }

    function RemoveFact($fact_id)
    {
        require("connection/expertSystemConnection.php");
        $removeFact = "DELETE FROM `fact` WHERE `fact`.id = '$fact_id'";
        $removeFactQuery = $expertSystemConnection->query($removeFact);      
    }
}

class Rule
{
    public $allRules;

    function __construct()
    {
        require("connection/expertSystemConnection.php");
        $selectRules = "SELECT * from `rule` ORDER BY `rule`.fact_id";
        $this->allRules = $expertSystemConnection->query($selectRules); 
    }

    function AddNewRule($fact_id, $rule_id, $result, $explanation, $object)
    {
        require("connection/expertSystemConnection.php");
        $addRule = "INSERT INTO `rule` (`fact_id`, `rule_id`, `result`, `explanation`, `object`) VALUES ('$fact_id', '$rule_id', '$result', '$explanation', '$object')";
        $addRuleQuery = $expertSystemConnection->query($addRule);
    }

    function RemoveRule($rule_id)
    {
        require("connection/expertSystemConnection.php");
        $removeRule = "DELETE FROM `rule` WHERE `rule`.id = '$rule_id'";
        $removeRuleQuery = $expertSystemConnection->query($removeRule);      
    }
}

class ExpertSystem
{
    public $rules; //Множество правил
    public $facts; //Множество фактов
    public $rulesThatWorked = array(); //Множество сработавших правил
    public $results = array();
    public $resultingDefects = array();
    public $resultingRecommendations = array();
    public $explanations = array();

    function __construct()
    {
        require("connection/expertSystemConnection.php");
        $rule = new Rule();
        $this->rules = $rule->allRules;

        $selectAllFacts = "SELECT `fact`.id FROM `fact`, `variable` WHERE `variable`.`id` = `fact`.`variable_id` AND (`variable`.`Name` = 'Неисправность' OR `variable`.`Name` = 'Дополнительно')";
        $this->facts = $expertSystemConnection->query($selectAllFacts); 
    }
    
    function CheckingFactOfTruth($fact_id, $domain_value)
    {
        require("connection/expertSystemConnection.php");
        $selectFactChecking = "SELECT `fact`.`id` FROM `fact`, `variable`, `domain`
        WHERE `variable`.`id` = `fact`.`variable_id` AND
        `domain`.`id` = `fact`.`domain_id` AND
        `variable`.`id` = '$fact_id' AND `domain`.`Value` = '$domain_value'";
        $selectFactCheckingQuery = $expertSystemConnection->query($selectFactChecking); 
        if($selectFactCheckingQuery->num_rows != 0)
        {
            $factChecking = $selectFactCheckingQuery->fetch_array();
            $selectFactAnnotation = "SELECT `fact`.Annotation from `fact` where `fact`.id = '$factChecking[0]' ";
            $selectFactAnnotationQuery = $expertSystemConnection->query($selectFactAnnotation);
            $annotation = $selectFactAnnotationQuery->fetch_array();

            $verifiedFacts = "INSERT INTO `WorkingMemory`(`fact_id`,`Annotation`) VALUES ('$factChecking[0]', '$annotation[0]')";
            $verifiedFactsQuery = $expertSystemConnection->query($verifiedFacts);
        }      
    }

    function SearchForWorkingRules()
    {
        require("connection/expertSystemConnection.php");
        $selectFactsFromWM = "SELECT * FROM `WorkingMemory`";
        $selectFactsFromWMQuery = $expertSystemConnection->query($selectFactsFromWM);
        while($factFromMW = $selectFactsFromWMQuery->fetch_array())
        {
            $selectTrueRule = "SELECT `rule`.id FROM `rule` WHERE `rule`.`fact_id` = '$factFromMW[1]'";
            $trueRuleQuery = $expertSystemConnection->query($selectTrueRule);
            $trueRule = $trueRuleQuery->fetch_array();
            array_push($this->rulesThatWorked, $trueRule[0]);
        }

        foreach($this->rulesThatWorked as $rule)
        {
            $selectCompoundRules = "SELECT `rule`.rule_id FROM `rule` WHERE `rule`.id = '$rule' AND `rule`.result IS NULL";
            $selectCompoundRulesQuery = $expertSystemConnection->query($selectCompoundRules);
            $CompoundRule = $selectCompoundRulesQuery->fetch_array();
            if($selectCompoundRulesQuery->num_rows != 0)
            {
                $selectCompoundRules = "SELECT `rule`.rule_id FROM `rule` WHERE `rule`.id = '$rule' AND `rule`.result IS NULL";
                $selectCompoundRulesQuery = $expertSystemConnection->query($selectCompoundRules);
                $linkToDerivedRule = $selectCompoundRulesQuery->fetch_array(); //Ссылка на производное правило
                if($key = array_search($linkToDerivedRule[0], $this->rulesThatWorked))
                {
                    $selectCompoundRulesResult = "SELECT `rule`.result FROM `rule` WHERE `rule`.id = '$key'";
                    $selectCompoundRulesResultQuery = $expertSystemConnection->query($selectCompoundRulesResult);
                    $compoundRuleResult = $selectCompoundRulesResultQuery->fetch_array();
                    array_push($this->results, $compoundRuleResult[0]);
                }   
                else
                {                                    
                $selectVariableOfCompoundRule = "SELECT `fact`.`variable_id`, `fact`.domain_id FROM `fact`, `rule`
                WHERE `fact`.`id` = (SELECT `rule`.`fact_id` FROM `rule` WHERE `rule`.`id` = '$CompoundRule[0]') AND `rule`.`fact_id` = `fact`.`id`";
                $selectVariableOfCompoundRuleQuery = $expertSystemConnection->query($selectVariableOfCompoundRule);
                $variableOfCompoundRule = $selectVariableOfCompoundRuleQuery->fetch_array();

                $selectCompoundRulesResult = "SELECT `rule`.result FROM `rule`, `fact` 
                WHERE `fact`.`variable_id` = '$variableOfCompoundRule[0]' AND 
                `rule`.`fact_id` = `fact`.`id` AND 
                `rule`.`result` != (SELECT `rule`.result FROM `rule` WHERE `rule`.`id` = '$linkToDerivedRule[0]')";
                $selectCompoundRulesResultQuery = $expertSystemConnection->query($selectCompoundRulesResult);
                $result = $selectCompoundRulesResultQuery->fetch_array();
                array_push($this->results, $result[0]);
                }

            }
            else
            {
                $selectRuleResult = "SELECT `rule`.result FROM `rule` WHERE `rule`.fact_id = '$rule'";
                $selectRuleResultQuery = $expertSystemConnection->query($selectRuleResult);
                $result = $selectRuleResultQuery->fetch_array();
                array_push($this->results, $result[0]);
                $this->results = array_unique($this->results);
            }
        }     
        $this->ProcessingOfResults(); //Обработка результата
        $this->OutputResults(); //Вывод результата   
        $this->AddServicesOnRepair();     
        $this->ClearingWorkingMemory();    
        
    }

    function OutputResults()
    {
        require("connection/expertSystemConnection.php");
        foreach($this->results as $result)
        {
            $selectDefects = "SELECT `domain`.`Value` from `fact`, `domain`, `variable`
            WHERE `fact`.`domain_id` = `domain`.`id` AND `fact`.`id` = '$result' AND `fact`.`variable_id` = `variable`.`id` AND `variable`.`Name` = 'Описание услуги'";
            $selectDefectsQuery = $expertSystemConnection->query($selectDefects);
            if($selectDefectsQuery->num_rows !=0)
            {                
                $defect = $selectDefectsQuery->fetch_array();
                array_push($this->resultingDefects, $defect[0]);
            }
            else
            {
                $selectRecommendations = "SELECT `domain`.`Value` from `fact`, `domain`, `variable` WHERE `fact`.`domain_id` = `domain`.`id` AND `fact`.`id` = '$result' AND `fact`.`variable_id` = `variable`.`id` AND `variable`.`Name` = 'Описание рекомендации'";
                $selectRecommendationsQuery = $expertSystemConnection->query($selectRecommendations);
                $recommandation = $selectRecommendationsQuery->fetch_array();
                array_push($this->resultingRecommendations, $recommandation[0]); 
            }  
        }   

        foreach($this->results as $resultID)
        {
            $selectExplanations = "SELECT `rule`.Explanation FROM `rule` WHERE `rule`.result = '$resultID'";
            $selectExplanationsQuery = $expertSystemConnection->query($selectExplanations);
            $explanation = $selectExplanationsQuery->fetch_array();
            array_push($this->explanations, $explanation[0]);
        }  
    }

    function ProcessingOfResults()
    {
        require("connection/expertSystemConnection.php");
        //Исключение неверных результатов из составных правил
        $inCorrectResults = array();
        $selectInCorrectRules = "SELECT `rule`.`id` FROM `rule` WHERE `rule`.`result` IS NULL";
        $selectInCorrectRulesQuery = $expertSystemConnection->query($selectInCorrectRules);
        while($inCorrectRule = $selectInCorrectRulesQuery->fetch_array())
        {
            array_push($inCorrectResults, $inCorrectRule[0]);
        }

        foreach($inCorrectResults as $inCorrect)
        {
            if(($key = array_search($inCorrect, $this->rulesThatWorked)) == false)
            {
                foreach($inCorrectResults as $inCorrect)
                {
                    $selectInCorrectResult = "SELECT `rule`.`result` FROM `rule`, `fact`
                    WHERE `rule`.`fact_id` = `fact`.`id` AND `fact`.`variable_id` = (SELECT `variable`.`id` from `variable`, `fact`, `rule`
                    WHERE `rule`.`id` = '$inCorrect' AND `rule`.`fact_id` = `fact`.`id` AND `fact`.`variable_id` = `variable`.`id`)";
                    $selectInCorrectResultQuery = $expertSystemConnection->query($selectInCorrectResult);
                    while($deletedResult = $selectInCorrectResultQuery->fetch_array())
                    {
                        if(($key = array_search($deletedResult[0], $this->results)) !== false)
                        {
                            unset($this->results[$key]);
                        }    
                    }
                }
            }
        }     
        //Замена двигателя
        $selectResultID = "SELECT `fact`.`id` FROM `fact`, `domain` WHERE `fact`.`domain_id` = `domain`.`id` AND `domain`.`Value` = 'Замена двигателя'";
        $selectResultIDQuery = $expertSystemConnection->query($selectResultID);
        $resultID = $selectResultIDQuery->fetch_array();
        if(in_array($resultID[0], $this->results))
        {
            $selectDeletedFacts = "SELECT `rule`.`result` FROM `rule` WHERE `rule`.`Object` = 'Двигатель' AND `rule`.result != '$resultID[0]'";
            $selectDeletedFactsQuery = $expertSystemConnection->query($selectDeletedFacts);
            while($deletedFact = $selectDeletedFactsQuery->fetch_array())
            {
                if(($key = array_search($deletedFact[0], $this->results)) !== false)
                {
                    unset($this->results[$key]);
                }                
            }
        }
        //Замена системы охлаждения
        $selectResultID = "SELECT `fact`.`id` FROM `fact`, `domain` WHERE `fact`.`domain_id` = `domain`.`id` AND `domain`.`Value` = 'Замена системы охлаждения'";
        $selectResultIDQuery = $expertSystemConnection->query($selectResultID);
        $resultID = $selectResultIDQuery->fetch_array();
        if(in_array($resultID[0], $this->results))
        {
            $selectDeletedFacts = "SELECT `rule`.`result` FROM `rule` WHERE `rule`.`Object` = 'Система охлаждения' AND `rule`.result != '$resultID[0]'";
            $selectDeletedFactsQuery = $expertSystemConnection->query($selectDeletedFacts);
            while($deletedFact = $selectDeletedFactsQuery->fetch_array())
            {
                if(($key = array_search($deletedFact[0], $this->results)) !== false)
                {
                    unset($this->results[$key]);
                }                
            }
        }
        //Замена тормозной системы
        $selectResultID = "SELECT `fact`.`id` FROM `fact`, `domain` WHERE `fact`.`domain_id` = `domain`.`id` AND `domain`.`Value` = 'Замена тормозной системы'";
        $selectResultIDQuery = $expertSystemConnection->query($selectResultID);
        $resultID = $selectResultIDQuery->fetch_array();
        if(in_array($resultID[0], $this->results))
        {
            $selectDeletedFacts = "SELECT `rule`.`result` FROM `rule` WHERE `rule`.`Object` = 'Тормозная система' AND `rule`.result != '$resultID[0]'";
            $selectDeletedFactsQuery = $expertSystemConnection->query($selectDeletedFacts);
            while($deletedFact = $selectDeletedFactsQuery->fetch_array())
            {
                if(($key = array_search($deletedFact[0], $this->results)) !== false)
                {
                    unset($this->results[$key]);
                }                
            }
        }
    }

    function AddServicesOnRepair() //Добавление услуг в ремонт
    {
        require("connection/connection.php");
        $serviceName;
        $servicePrice;
        $recommendationName;
        $recommendationPrice;

        foreach($this->resultingDefects as $defect)
        {
            $selectServices = "SELECT `service`.`ServiceName`, `service`.`ServicePrice` FROM `service` WHERE `service`.`ServiceName` = '$defect'";
            $selectServicesQuery = $autoproConnection->query($selectServices);
            $service = $selectServicesQuery->fetch_array();
            $serviceName .= "$service[0] / ";
            $servicePrice += $service[1];
        }

        foreach($this->resultingRecommendations as $recommendation)
        {
            $selectRecommendation = "SELECT `recommendations`.`recommendationsName`, `recommendations`.`recommendationsPrice` FROM `recommendations` WHERE `recommendations`.`recommendationsName` = '$recommendation'";
            $selectRecommendationQuery = $autoproConnection->query($selectRecommendation);
            $rec = $selectRecommendationQuery->fetch_array();
            $recommandationName .= "$rec[0] / ";
            $recommandationPrice += $rec[1];
        }
        require("connection/connection.php");
        $insertService = "INSERT INTO `carrepair`(`used_service`, `used_recommendation`, `TotalPriceOfServices`, `TotalPriceOfRecommendations`) VALUES ('$serviceName', '$recommandationName', '$servicePrice', '$recommandationPrice')";
        $insertServiceQuery = $autoproConnection->query($insertService);
    }

    function ClearingWorkingMemory()
    {
        require("connection/expertSystemConnection.php");
        $dropWorkingMemory = "DELETE FROM `workingMemory`";
        $dropWorkingMemoryQuery = $expertSystemConnection->query($dropWorkingMemory);
        $resetOfIncrement = "ALTER TABLE `workingMemory` AUTO_INCREMENT = 0";
        $resetOfIncrementQuery = $expertSystemConnection->query($resetOfIncrement);
    }
}
?>