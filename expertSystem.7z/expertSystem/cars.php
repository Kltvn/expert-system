<?php
       if(isset($_POST['addCarButton']))
       {
           $carBrand = $_POST['carBrand'];
           $carModel = $_POST['carModel'];
           $carYearOfRelease = $_POST['carYearOfRelease'];
           $carStateNumber = $_POST['carStateNumber'];
           $clientID = $_POST['clientID'];
           $characteristicID = $_POST['characteristicID'];

           if(!empty($carBrand) && !empty($carModel) && !empty($carYearOfRelease) && !empty($carStateNumber)
           && !empty($clientID) && !empty($characteristicID))
           {
               require("autoPRO.php");
               $car = new Car($carBrand, $carModel, $carYearOfRelease, $carStateNumber, $clientID[0], $characteristicID[0]);
               $car->AddCar();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['updateCarButton']))
       {
           $carID = $_POST['carID'];
           $carBrand = $_POST['carBrand'];
           $carModel = $_POST['carModel'];
           $carYearOfRelease = $_POST['carYearOfRelease'];
           $carStateNumber = $_POST['carStateNumber'];
           $clientID = $_POST['clientID'];
           $characteristicID = $_POST['characteristicID'];

           if(!empty($carBrand) && !empty($carModel) && !empty($carYearOfRelease) && !empty($carStateNumber)
           && !empty($clientID) && !empty($characteristicID))
           {
               require("autoPRO.php");
               $car = new Car($carBrand, $carModel, $carYearOfRelease, $carStateNumber, $clientID[0], $characteristicID[0]);
               $car->UpdateCar($carID, $carBrand, $carModel, $carYearOfRelease, $carStateNumber, $clientID[0], $characteristicID[0]);
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteCarButton']))
       {
           $carID = $_POST['carID'];
           $carBrand = $_POST['carBrand'];
           $carModel = $_POST['carModel'];
           $carYearOfRelease = $_POST['carYearOfRelease'];
           $carStateNumber = $_POST['carStateNumber'];
           $clientID = $_POST['clientID'];
           $characteristicID = $_POST['characteristicID'];
   
           require("autoPRO.php");
           $car = new Car($carBrand, $carModel, $carYearOfRelease, $carStateNumber, $clientID[0], $characteristicID[0]);
           $car->DeleteCar($carID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addCharacteristicsButton']))
       {
           $characteristicName = $_POST['characteristicName'];
           $producingCountry = $_POST['producingCountry'];
           $engineID = $_POST['engineID'];
           $transmissionID = $_POST['transmissionID'];
           $coolingSystemID = $_POST['coolingSystemID'];
           $brakeSystemID = $_POST['brakeSystemID'];
           $electronicsID = $_POST['electronicsID'];
           $steeringSystemID = $_POST['steeringSystemID'];
           $runningSystemID = $_POST['runningSystemID'];
           $releaseSystemID = $_POST['releaseSystemID'];

           if(!empty($characteristicName) && !empty($producingCountry) && !empty($engineID) && !empty($transmissionID)
           && !empty($coolingSystemID) && !empty($brakeSystemID) && !empty($electronicsID) && !empty($steeringSystemID) && !empty($runningSystemID)
           && !empty($releaseSystemID) )
           {
               require("autoPRO.php");
               $characteristics = new Characteristics($characteristicName, $producingCountry, $engineID[0], $transmissionID[0], $coolingSystemID[0], $brakeSystemID[0], $electronicsID[0], $steeringSystemID[0], $runningSystemID[0], $releaseSystemID[0]);
               $characteristics->AddCharacteristics();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['updateCharacteristicsButton']))
       {
           $characteristicID = $_POST['characteristicID'];
           $characteristicName = $_POST['characteristicName'];
           $producingCountry = $_POST['producingCountry'];
           $engineID = $_POST['engineID'];
           $transmissionID = $_POST['transmissionID'];
           $coolingSystemID = $_POST['coolingSystemID'];
           $brakeSystemID = $_POST['brakeSystemID'];
           $electronicsID = $_POST['electronicsID'];
           $steeringSystemID = $_POST['steeringSystemID'];
           $runningSystemID = $_POST['runningSystemID'];
           $releaseSystemID = $_POST['releaseSystemID'];

           if(!empty($characteristicName) && !empty($producingCountry) && !empty($engineID) && !empty($transmissionID)
           && !empty($coolingSystemID) && !empty($brakeSystemID) && !empty($electronicsID) && !empty($steeringSystemID) && !empty($runningSystemID)
           && !empty($releaseSystemID) )
           {
               require("autoPRO.php");
               $characteristics = new Characteristics($characteristicName, $producingCountry, $engineID[0], $transmissionID[0], $coolingSystemID[0], $brakeSystemID[0], $electronicsID[0], $steeringSystemID[0], $runningSystemID[0], $releaseSystemID[0]);
               $characteristics->UpdateCharacteristics($characteristicID, $characteristicName, $producingCountry, $engineID[0], $transmissionID[0], $coolingSystemID[0], $brakeSystemID[0], $electronicsID[0], $steeringSystemID[0], $runningSystemID[0], $releaseSystemID[0]);
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteCharacteristicsButton']))
       {
        $characteristicID = $_POST['characteristicID'];
        $characteristicName = $_POST['characteristicName'];
        $producingCountry = $_POST['producingCountry'];
        $engineID = $_POST['engineID'];
        $transmissionID = $_POST['transmissionID'];
        $coolingSystemID = $_POST['coolingSystemID'];
        $brakeSystemID = $_POST['brakeSystemID'];
        $electronicsID = $_POST['electronicsID'];
        $steeringSystemID = $_POST['steeringSystemID'];
        $runningSystemID = $_POST['runningSystemID'];
        $releaseSystemID = $_POST['releaseSystemID'];
   
        require("autoPRO.php");
        $characteristics = new Characteristics($characteristicName, $producingCountry, $engineID[0], $transmissionID[0], $coolingSystemID[0], $brakeSystemID[0], $electronicsID[0], $steeringSystemID[0], $runningSystemID[0], $releaseSystemID[0]);
        $characteristics->DeleteCharacteristics($characteristicID);
        header("Location: http://expertsystem/cars.php");
       }
       
       if(isset($_POST['addEngineButton']))
       {
           $engineName = $_POST['engineName'];
           $engineCapacity = $_POST['engineCapacity'];
           $countOfCylinders = $_POST['countOfCylinders'];
           $enginePower = $_POST['enginePower'];
           $engineTorque = $_POST['engineTorque'];
           $gasolineConsumption = $_POST['gasolineConsumption'];
           $oilConsumption = $_POST['oilConsumption'];

           if(!empty($carBrand) && !is_int($engineCapacity) && !is_int($countOfCylinders) && !is_int($enginePower)
           && !is_int($engineTorque) && !is_int($gasolineConsumption) && !is_int($oilConsumption))
           {
               require("autoPRO.php");
               $engine = new Engine($engineName, $engineCapacity, $countOfCylinders, $enginePower, $engineTorque, $gasolineConsumption, $oilConsumption);
               $engine->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteEngineButton']))
       {
           $engineID = $_POST['engineID'];
           $engineCapacity = $_POST['engineCapacity'];
           $countOfCylinders = $_POST['countOfCylinders'];
           $enginePower = $_POST['enginePower'];
           $engineTorque = $_POST['engineTorque'];
           $gasolineConsumption = $_POST['gasolineConsumption'];
           $oilConsumption = $_POST['oilConsumption'];
   
           require("autoPRO.php");
           $engine = new Engine($engineName, $engineCapacity, $countOfCylinders, $enginePower, $engineTorque, $gasolineConsumption, $oilConsumption);
            $engine->DeleteAutopart($engineID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addTransmissionButton']))
       {
           $transmissionName = $_POST['transmissionName'];
           $transmissionType = $_POST['transmissionType'];
           $countOfGears = $_POST['countOfGears'];
           $typeOfDrive = $_POST['typeOfDrive'];
           $workResource = $_POST['workResource'];

           if(!empty($transmissionName) && !empty($transmissionType) && !is_int($countOfGears) && !empty($typeOfDrive)
           && !is_int($workResource))
           {
               require("autoPRO.php");
               $transmission = new Transmission($transmissionName, $transmissionType, $countOfGears, $typeOfDrive, $workResource);
               $transmission->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteTransmissionButton']))
       {
           $transmissionID = $_POST['transmissionID'];
           $transmissionName = $_POST['transmissionName'];
           $transmissionType = $_POST['transmissionType'];
           $countOfGears = $_POST['countOfGears'];
           $typeOfDrive = $_POST['typeOfDrive'];
           $workResource = $_POST['workResource'];
   
           require("autoPRO.php");
           $transmission = new Transmission($transmissionName, $transmissionType, $countOfGears, $typeOfDrive, $workResource);
            $transmission->DeleteAutopart($transmissionID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addCoolingSystemButton']))
       {
           $coolingSystemName = $_POST['coolingSystemName'];
           $radiatorMaterial = $_POST['radiatorMaterial'];
           $hoseMaterial = $_POST['hoseMaterial'];
           $coolantVolume = $_POST['coolantVolume'];

           if(!empty($coolingSystemName) && !empty($radiatorMaterial) && !empty($hoseMaterial) && !is_int($coolantVolume))
           {
               require("autoPRO.php");
               $coolingSystem = new CoolingSystem($coolingSystemName, $radiatorMaterial, $hoseMaterial, $coolantVolume);
               $coolingSystem->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteCoolingSystemButton']))
       {
           $coolingSystemID = $_POST['coolingSystemID'];
           $coolingSystemName = $_POST['coolingSystemName'];
           $radiatorMaterial = $_POST['radiatorMaterial'];
           $hoseMaterial = $_POST['hoseMaterial'];
           $coolantVolume = $_POST['coolantVolume'];
   
           require("autoPRO.php");
           $coolingSystem = new CoolingSystem($coolingSystemName, $radiatorMaterial, $hoseMaterial, $coolantVolume);
           $coolingSystem->DeleteAutopart($coolingSystemID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addBrakeSystemButton']))
       {
           $brakeSystemName = $_POST['brakeSystemName'];
           $hydraulicVolume = $_POST['hydraulicVolume'];
           $countOfParkingBrakeClicks = $_POST['countOfParkingBrakeClicks'];
           $frontBrakes = $_POST['frontBrakes'];
           $rearBrakes = $_POST['rearBrakes'];

           if(!empty($brakeSystemName) && !is_real($hydraulicVolume) && !is_int($countOfParkingBrakeClicks) && !empty($frontBrakes) && !empty($rearBrakes))
           {
               require("autoPRO.php");
               $brakeSystem = new BrakeSystem($brakeSystemName, $hydraulicVolume, $countOfParkingBrakeClicks, $frontBrakes, $rearBrakes);
               $brakeSystem->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteBrakeSystemButton']))
       {
           $brakeSystemID = $_POST['brakeSystemID'];
           $brakeSystemName = $_POST['brakeSystemName'];
           $hydraulicVolume = $_POST['hydraulicVolume'];
           $countOfParkingBrakeClicks = $_POST['countOfParkingBrakeClicks'];
           $frontBrakes = $_POST['frontBrakes'];
           $rearBrakes = $_POST['rearBrakes'];
   
           require("autoPRO.php");
           $brakeSystem = new BrakeSystem($brakeSystemName, $hydraulicVolume, $countOfParkingBrakeClicks, $frontBrakes, $rearBrakes);
           $brakeSystem->DeleteAutopart($brakeSystemID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addElectronicsButton']))
       {
           $electronicsName = $_POST['electronicsName'];
           $typeOfElectricalNetwork = $_POST['typeOfElectricalNetwork'];
           $batteryCapacity = $_POST['batteryCapacity'];
           $batteryCurrentStrength = $_POST['batteryCurrentStrength'];
           $generatorModel = $_POST['generatorModel'];
           $generatorCurrentStrength = $_POST['generatorCurrentStrength'];

           if(!empty($electronicsName) && !empty($typeOfElectricalNetwork) && !is_int($batteryCapacity) && !is_int($batteryCurrentStrength) 
           && !empty($generatorModel) && !is_int($generatorCurrentStrength))
           {
               require("autoPRO.php");
               $electronics = new Electronics($electronicsName, $typeOfElectricalNetwork, $batteryCapacity, $batteryCurrentStrength, $generatorModel, $generatorCurrentStrength);
               $electronics->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteElectronicsButton']))
       {
           $electronicsID = $_POST['electronicsID'];
           $electronicsName = $_POST['electronicsName'];
           $typeOfElectricalNetwork = $_POST['typeOfElectricalNetwork'];
           $batteryCapacity = $_POST['batteryCapacity'];
           $batteryCurrentStrength = $_POST['batteryCurrentStrength'];
           $generatorModel = $_POST['generatorModel'];
           $generatorCurrentStrength = $_POST['generatorCurrentStrength'];
   
           require("autoPRO.php");
           $electronics = new Electronics($electronicsName, $typeOfElectricalNetwork, $batteryCapacity, $batteryCurrentStrength, $generatorModel, $generatorCurrentStrength);
           $electronics->DeleteAutopart($electronicsID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addSteeringSystemButton']))
       {
           $steeringSystemName = $_POST['steeringSystemName'];
           $freeSteering = $_POST['freeSteering'];
           $modelCompatibility = $_POST['modelCompatibility'];

           if(!empty($steeringSystemName) && !is_int($freeSteering) && !empty($modelCompatibility))
           {
               require("autoPRO.php");
               $steeringSystem = new SteeringSystem($steeringSystemName, $freeSteering, $modelCompatibility);
               $steeringSystem->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteSteeringSystemButton']))
       {
           $steeringSystemID = $_POST['steeringSystemID'];
           $steeringSystemName = $_POST['steeringSystemName'];
           $freeSteering = $_POST['freeSteering'];
           $modelCompatibility = $_POST['modelCompatibility'];
   
           require("autoPRO.php");
           $steeringSystem = new SteeringSystem($steeringSystemName, $freeSteering, $modelCompatibility);
           $steeringSystem->DeleteAutopart($steeringSystemID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addRunningSystemButton']))
       {
           $runningSystemName = $_POST['runningSystemName'];
           $suspensionClassification = $_POST['suspensionClassification'];
           $typeOfFrontSuspension = $_POST['typeOfFrontSuspension'];
           $typeOfRearSuspension = $_POST['typeOfRearSuspension'];
           $workingEnvironmentOfAbsorbers = $_POST['workingEnvironmentOfAbsorbers'];

           if(!empty($runningSystemName) && !empty($suspensionClassification) && !empty($typeOfFrontSuspension) && !empty($typeOfRearSuspension)
           && !empty($workingEnvironmentOfAbsorbers))
           {
               require("autoPRO.php");
               $runningSystem = new RunningSystem($runningSystemName, $suspensionClassification, $typeOfFrontSuspension, $typeOfRearSuspension, $workingEnvironmentOfAbsorbers);
               $runningSystem->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteRunningSystemButton']))
       {
           $runningSystemID = $_POST['runningSystemID'];
           $runningSystemName = $_POST['runningSystemName'];
           $suspensionClassification = $_POST['suspensionClassification'];
           $typeOfFrontSuspension = $_POST['typeOfFrontSuspension'];
           $typeOfRearSuspension = $_POST['typeOfRearSuspension'];
           $workingEnvironmentOfAbsorbers = $_POST['workingEnvironmentOfAbsorbers'];
   
           require("autoPRO.php");
           $runningSystem = new RunningSystem($runningSystemName, $suspensionClassification, $typeOfFrontSuspension, $typeOfRearSuspension, $workingEnvironmentOfAbsorbers);
           $runningSystem->DeleteAutopart($runningSystemID);
           header("Location: http://expertsystem/cars.php");
       }

       if(isset($_POST['addReleaseSystemButton']))
       {
           $releaseSystemName = $_POST['releaseSystemName'];
           $silencerMaterial = $_POST['silencerMaterial'];
           $typeOfExhaustManifold = $_POST['typeOfExhaustManifold'];

           if(!empty($releaseSystemName) && !empty($silencerMaterial) && !empty($typeOfExhaustManifold))
           {
               require("autoPRO.php");
               $releaseSystem = new ReleaseSystem($releaseSystemName, $silencerMaterial, $typeOfExhaustManifold);
               $releaseSystem->AddAutopart();
               header("Location: http://expertsystem/cars.php");
           }
       }
       if(isset($_POST['deleteReleaseSystemButton']))
       {
           $releaseSystemID = $_POST['releaseSystemID'];
           $releaseSystemName = $_POST['releaseSystemName'];
           $silencerMaterial = $_POST['silencerMaterial'];
           $typeOfExhaustManifold = $_POST['typeOfExhaustManifold'];
   
           require("autoPRO.php");
           $releaseSystem = new ReleaseSystem($releaseSystemName, $silencerMaterial, $typeOfExhaustManifold);
           $releaseSystem->DeleteAutopart($releaseSystemID);
           header("Location: http://expertsystem/cars.php");
       }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> База автомобилей </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="title">
    <div class="subtitle_first"> Автомобили </div>
</div>

<div class="cars">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Марка</th>
        <th>Модель</th>
        <th>Год выпуска</th>
        <th>Государственный номер</th>
        <th>ФИО владельца</th>
        <th>Номер комплектации</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutCar = "SELECT `car`.`id`, `car`.`CarBrand`, `car`.`CarModel`, `car`.`CarYearOfRelease`, `car`.`CarStateNumber`, `client`.`Name`, `client`.`Surname`, `client`.`Middlename`, `car`.`id_characteristic` FROM `car`, `client`
        WHERE `client`.`id` = `car`.`id_client`";
        $selectInformationAboutCarQuery = $autoproConnection->query($selectInformationAboutCar);
        while($info = $selectInformationAboutCarQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5], " ", $info[6], " ", $info[7]; ?></td>
                <td><?php echo $info[8]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление автомобиля </div>

    <form class="operation_form" name="addCarForm" method="post">
        <div class="addCar">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите марку: </div>
                <textarea class="textareaClass" name="carBrand"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите модель: </div>
                <textarea class="textareaClass" name="carModel"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите год выпуска (ГГГГ-ММ-ДД): </div>
                <textarea class="textareaClass" name="carYearOfRelease"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите государственный номер: </div>
                <textarea class="textareaClass" name="carStateNumber"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите владельца: </div>
                <select class="selectClass" name="clientID">
                <?php require("connection/connection.php");
                $selectClient = "SELECT `client`.id, `client`.name, `client`.surname FROM `client`";
                $selectClientQuery = $autoproConnection->query($selectClient);
                while($client = $selectClientQuery->fetch_array())
                {?>
                    <option><?php echo $client['id'], "-", $client['name'], " ", $client['surname']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите комплектацию: </div>
                <select class="selectClass" name="characteristicID">
                <?php require("connection/connection.php");
                $selectCharacteristic = "SELECT `characteristics`.id, `characteristics`.name FROM `characteristics`";
                $selectCharacteristicQuery = $autoproConnection->query($selectCharacteristic);
                while($characteristic = $selectCharacteristicQuery->fetch_array())
                {?>
                    <option><?php echo $characteristic['id'], "-", $characteristic['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>

            <input class="submitButton" type="submit" name="addCarButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Изменение автомобиля </div>

    <form class="operation_form" name="updateCarForm" method="post">
        <div class="updateCar">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID автомобиля: </div>
                <select class="selectClass" name="carID">
                <?php require("connection/connection.php");
                $selectCarID = "SELECT `car`.id FROM `car`";
                $selectCarIDQuery = $autoproConnection->query($selectCarID);
                while($carID = $selectCarIDQuery->fetch_array())
                {?>
                    <option><?php echo $carID['id']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите марку: </div>
                <textarea class="textareaClass" name="carBrand"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите модель: </div>
                <textarea class="textareaClass" name="carModel"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите год выпуска (ГГГГ-ММ-ДД): </div>
                <textarea class="textareaClass" name="carYearOfRelease"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите государственный номер: </div>
                <textarea class="textareaClass" name="carStateNumber"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите владельца: </div>
                <select class="selectClass" name="clientID">
                <?php require("connection/connection.php");
                $selectClient = "SELECT `client`.id, `client`.name, `client`.surname FROM `client`";
                $selectClientQuery = $autoproConnection->query($selectClient);
                while($client = $selectClientQuery->fetch_array())
                {?>
                    <option><?php echo $client['id'], "-", $client['name'], " ", $client['surname']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите комплектацию: </div>
                <select class="selectClass" name="characteristicID">
                <?php require("connection/connection.php");
                $selectCharacteristic = "SELECT `characteristics`.id, `characteristics`.name FROM `characteristics`";
                $selectCharacteristicQuery = $autoproConnection->query($selectCharacteristic);
                while($characteristic = $selectCharacteristicQuery->fetch_array())
                {?>
                    <option><?php echo $characteristic['id'], "-", $characteristic['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>

            <input class="submitButton" type="submit" name="updateCarButton" value="Изменить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление автомобиля </div>

    <form class="operation_form" name="deleteCarForm" method="post">
        <div class="deleteCar">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID автомобиля: </div>
                <select class="selectClass" name="carID">
                <?php require("connection/connection.php");
                $selectCarID = "SELECT `car`.id FROM `car`";
                $selectCarIDQuery = $autoproConnection->query($selectCarID);
                while($carID = $selectCarIDQuery->fetch_array())
                {?>
                    <option><?php echo $carID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteCarButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Двигатели </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Объем, л.</th>
        <th>Количество цилиндров</th>
        <th>Мощность, л.с.</th>
        <th>Крутящий момент, Нм</th>
        <th>Расход бензина, л/100км </th>
        <th>Расход масла, л/100км </th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutEngine = "SELECT * FROM `engine`";
        $selectInformationAboutEngineQuery = $autoproConnection->query($selectInformationAboutEngine);
        while($info = $selectInformationAboutEngineQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
                <td><?php echo $info[6]; ?></td>
                <td><?php echo $info[7]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление двигателя </div>

    <form class="operation_form" name="addEngineForm" method="post">
        <div class="addEngine">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="engineName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите объем, л.: </div>
                <textarea class="textareaClass" name="engineCapacity"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите количество цилиндров: </div>
                <textarea class="textareaClass" name="countOfCylinders"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите мощность, л.с.: </div>
                <textarea class="textareaClass" name="enginePower"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите крутящий момент, Нм: </div>
                <textarea class="textareaClass" name="engineTorque"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите расход бензина, л/100км: </div>
                <textarea class="textareaClass" name="gasolineConsumption"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите расход масла, л/100км: </div>
                <textarea class="textareaClass" name="oilConsumption"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addEngineButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление двигателя </div>

    <form class="operation_form" name="deleteEngineForm" method="post">
        <div class="deleteEngine">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID двигателя: </div>
                <select class="selectClass" name="carID">
                <?php require("connection/connection.php");
                $selectEngineID = "SELECT `engine`.id FROM `engine`";
                $selectEngineIDQuery = $autoproConnection->query($selectEngineID);
                while($engineID = $selectEngineIDQuery->fetch_array())
                {?>
                    <option><?php echo $engineID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteEngineButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Трансмиссии </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Тип трансмисии</th>
        <th>Количество передач</th>
        <th>Тип привода</th>
        <th>Заводской ресурс коробки передач</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutTransmission = "SELECT * FROM `transmission`";
        $selectInformationAboutTransmissionQuery = $autoproConnection->query($selectInformationAboutTransmission);
        while($info = $selectInformationAboutTransmissionQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление трансмиссии </div>

    <form class="operation_form" name="addTransmissionForm" method="post">
        <div class="addTransmission">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="transmissionName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип трансмисии: </div>
                <select class="selectClass" name="transmissionType">
                    <option> Механическая </option>
                    <option> Автомат </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите количество передач: </div>
                <textarea class="textareaClass" name="countOfGears"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип привода: </div>
                <select class="selectClass" name="typeOfDrive">
                    <option> Передний </option>
                    <option> Задний </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите заводской ресурс коробки передач: </div>
                <textarea class="textareaClass" name="workResource"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addTransmissionButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление трансмиссии </div>

    <form class="operation_form" name="deleteTransmissionForm" method="post">
        <div class="deleteTransmission">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID трансмиссии: </div>
                <select class="selectClass" name="transmissionID">
                <?php require("connection/connection.php");
                $selectTransmissionID = "SELECT `transmission`.id FROM `transmission`";
                $selectTransmissionIDQuery = $autoproConnection->query($selectTransmissionID);
                while($transmissionID = $selectTransmissionIDQuery->fetch_array())
                {?>
                    <option><?php echo $transmissionID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteTransmissionButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Системы охлаждения </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Материал радитора</th>
        <th>Материал патрубков</th>
        <th>Объем охлаждающей жидкости, л.</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutCoolingSystem = "SELECT * FROM `coolingSystem`";
        $selectInformationAboutCoolingSystemQuery = $autoproConnection->query($selectInformationAboutCoolingSystem);
        while($info = $selectInformationAboutCoolingSystemQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление охлаждающей системы </div>

    <form class="operation_form" name="addCoolingSystemForm" method="post">
        <div class="addCoolingSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="coolingSystemName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите материал радиатора: </div>
                <textarea class="textareaClass" name="radiatorMaterial"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите материал патрубков: </div>
                <textarea class="textareaClass" name="hoseMaterial"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите объем охлаждающей жидкости, л.: </div>
                <textarea class="textareaClass" name="coolantVolume"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addCoolingSystemButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление системы охлаждения </div>

    <form class="operation_form" name="deleteCoolingSystemForm" method="post">
        <div class="deleteCoolingSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID охлаждающей системы: </div>
                <select class="selectClass" name="coolingSystemID">
                <?php require("connection/connection.php");
                $selectCoolingSystemID = "SELECT `coolingsystem`.id FROM `coolingsystem`";
                $selectCoolingSystemIDQuery = $autoproConnection->query($selectCoolingSystemID);
                while($coolingsystemID = $selectCoolingSystemIDQuery->fetch_array())
                {?>
                    <option><?php echo $coolingsystemID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteCoolingSystemButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Тормозные системы </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Объем гидропривода, л.</th>
        <th>Количество щелчков стояночного тормоза</th>
        <th>Передние тормоза</th>
        <th>Задние тормоза</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutBrakeSystem = "SELECT * FROM `brakeSystem`";
        $selectInformationAboutBrakeSystemQuery = $autoproConnection->query($selectInformationAboutBrakeSystem);
        while($info = $selectInformationAboutBrakeSystemQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление тормозной системы </div>

    <form class="operation_form" name="addBrakeSystemForm" method="post">
        <div class="addBrakeSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="brakeSystemName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите объем гидропривода, л.: </div>
                <textarea class="textareaClass" name="hydraulicVolume"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите количество щелчков стояночного тормоза: </div>
                <textarea class="textareaClass" name="countOfParkingBrakeClicks"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип передних тормозов: </div>
                <select class="selectClass" name="frontBrakes">
                    <option> Дисковые </option>
                    <option> Барабанные </option>
                    <option> Ободочные </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип задних тормозов: </div>
                <select class="selectClass" name="rearBrakes">
                    <option> Дисковые </option>
                    <option> Барабанные </option>
                    <option> Ободочные </option>
                </select>
            </div>

            <input class="submitButton" type="submit" name="addBrakeSystemButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление тормозной системы </div>

    <form class="operation_form" name="deleteBrakeSystemForm" method="post">
        <div class="deleteBrakeSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID тормозной системы: </div>
                <select class="selectClass" name="brakeSystemID">
                <?php require("connection/connection.php");
                $selectbrakeSystemID = "SELECT `brakeSystem`.id FROM `brakeSystem`";
                $selectbrakeSystemIDQuery = $autoproConnection->query($selectbrakeSystemID);
                while($brakeSystemID = $selectbrakeSystemIDQuery->fetch_array())
                {?>
                    <option><?php echo $brakeSystemID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteBrakeSystemButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Электрооборудования </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Тип электрической сети</th>
        <th>Емкость аккумулятора, Ач</th>
        <th>Сила тока аккумулятора, А</th>
        <th>Модель генератора</th>
        <th>Сила тока генератора, А</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutElectronics = "SELECT * FROM `electronics`";
        $selectInformationAboutElectronicsQuery = $autoproConnection->query($selectInformationAboutElectronics);
        while($info = $selectInformationAboutElectronicsQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
                <td><?php echo $info[6]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление электрооборудования </div>

    <form class="operation_form" name="addElectronicsForm" method="post">
        <div class="addElectronics">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="electronicsName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип электричкой сети: </div>
                <select class="selectClass" name="typeOfElectricalNetwork">
                    <option> Однопроводная </option>
                    <option> Двухпроводная </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите емкость аккумулятора, Ач: </div>
                <textarea class="textareaClass" name="batteryCapacity"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите силу тока аккумулятора, А: </div>
                <textarea class="textareaClass" name="batteryCurrentStrength"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите модель генератора: </div>
                <textarea class="textareaClass" name="generatorModel"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите силу тока генератора, А: </div>
                <textarea class="textareaClass" name="generatorCurrentStrength"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addElectronicsButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление электрооборудования </div>

    <form class="operation_form" name="deleteElectronicsForm" method="post">
        <div class="deleteElectronics">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID электрооборудования: </div>
                <select class="selectClass" name="electronicsID">
                <?php require("connection/connection.php");
                $selectElectronicsID = "SELECT `electronics`.id FROM `electronics`";
                $selectElectronicsIDQuery = $autoproConnection->query($selectElectronicsID);
                while($electronicsID = $selectElectronicsIDQuery->fetch_array())
                {?>
                    <option><?php echo $electronicsID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteElectronicsButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Рулевые системы </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Свободный ход рулевого колеса, град.</th>
        <th>Совместимость с моделями</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutSteeringSystem = "SELECT * FROM `steeringSystem`";
        $selectInformationAboutSteeringSystemQuery = $autoproConnection->query($selectInformationAboutSteeringSystem);
        while($info = $selectInformationAboutSteeringSystemQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление рулевой системы </div>

    <form class="operation_form" name="addSteeringSystemForm" method="post">
        <div class="addSteeringSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="steeringSystemName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите свободный ход рулевого колеса, град.: </div>
                <textarea class="textareaClass" name="freeSteering"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите совместимые модели: </div>
                <textarea class="textareaClass" name="modelCompatibility"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addSteeringSystemButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление рулевой системы </div>

    <form class="operation_form" name="deleteSteeringSystemForm" method="post">
        <div class="deleteSteeringSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID рулевой системы: </div>
                <select class="selectClass" name="steeringSystemID">
                <?php require("connection/connection.php");
                $selectSteeringSystemID = "SELECT `steeringSystem`.id FROM `steeringSystem`";
                $selectSteeringSystemIDQuery = $autoproConnection->query($selectSteeringSystemID);
                while($steeringSystemID = $selectSteeringSystemIDQuery->fetch_array())
                {?>
                    <option><?php echo $steeringSystemID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteSteeringSystemButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Ходовые системы </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Классификация подвески</th>
        <th>Тип передней подвески</th>
        <th>Тип задней подвески</th>
        <th>Рабочая среда амортизаторов</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutRunningSystem = "SELECT * FROM `runningSystem`";
        $selectInformationAboutRunningSystemQuery = $autoproConnection->query($selectInformationAboutRunningSystem);
        while($info = $selectInformationAboutRunningSystemQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление ходовой системы </div>

    <form class="operation_form" name="addRunningSystemForm" method="post">
        <div class="addRunningSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="runningSystemName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите классификацию подвески: </div>
                <select class="selectClass" name="suspensionClassification">
                    <option> Зависимая </option>
                    <option> Полунезависимая </option>
                    <option> Независимая </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип передней подвески: </div>
                <select class="selectClass" name="typeOfFrontSuspension">
                    <option> Независимая, пружинная </option>
                    <option> Полунезависимая, пружинная </option>
                    <option> Независимая, торсионная </option>
                    <option> Полунезависимая, торсионная </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип задней подвески: </div>
                <select class="selectClass" name="typeOfRearSuspension">
                    <option> Независимая, пружинная </option>
                    <option> Полунезависимая, пружинная </option>
                    <option> Независимая, торсионная </option>
                    <option> Полунезависимая, торсионная </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите рабочую среду амортизаторов: </div>
                <select class="selectClass" name="workingEnvironmentOfAbsorbers">
                    <option> Масляная </option>
                    <option> Газовая </option>
                </select>
            </div>

            <input class="submitButton" type="submit" name="addRunningSystem" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление ходовой системы </div>

    <form class="operation_form" name="deleteRunningSystemForm" method="post">
        <div class="deleteRunningSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID ходовой системы: </div>
                <select class="selectClass" name="runningSystemID">
                <?php require("connection/connection.php");
                $selectRunningSystemID = "SELECT `runningSystem`.id FROM `runningSystem`";
                $selectRunningSystemIDQuery = $autoproConnection->query($selectRunningSystemID);
                while($runningSystemID = $selectRunningSystemIDQuery->fetch_array())
                {?>
                    <option><?php echo $runningSystemID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteRunningSystemButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Системы выпуска </div>
</div>

<div class="characteristic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Материал глушителя</th>
        <th>Вид выпускного коллектора</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutReleaseSystem = "SELECT * FROM `releaseSystem`";
        $selectInformationAboutReleaseSystemQuery = $autoproConnection->query($selectInformationAboutReleaseSystem);
        while($info = $selectInformationAboutReleaseSystemQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление системы выпуска </div>

    <form class="operation_form" name="addReleaseSystemForm" method="post">
        <div class="addReleaseSystem">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="releaseSystemName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите материал глушителя: </div>
                <select class="selectClass" name="silencerMaterial">
                    <option> Алюминий </option>
                    <option> Нержавейка </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите вид выпускного коллектора: </div>
                <select class="selectClass" name="typeOfExhaustManifold">
                    <option> Цельный </option>
                    <option> Трубчатый </option>
                </select>
            </div>

            <input class="submitButton" type="submit" name="addReleaseSystemButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление системы выпуска </div>

    <form class="operation_form" name="deleteReleaseSystemForm" method="post">
        <div class="deleteReleaseSystemForm">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID системы выпуска: </div>
                <select class="selectClass" name="releaseSystemID">
                <?php require("connection/connection.php");
                $selectReleaseSystemID = "SELECT `releaseSystem`.id FROM `releaseSystem`";
                $selectReleaseSystemIDQuery = $autoproConnection->query($selectReleaseSystemID);
                while($releaseSystemID = $selectReleaseSystemIDQuery->fetch_array())
                {?>
                    <option><?php echo $releaseSystemID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteReleaseSystemButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Комплектации </div>
</div>

<div class="characterictic">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Наименование</th>
        <th>Страна производитель</th>
        <th>Двигатель</th>
        <th>Трансмиссия</th>
        <th>Система охлаждения</th>
        <th>Тормозная система</th>
        <th>Электроника</th>
        <th>Рулевая система</th>
        <th>Ходовая система</th>
        <th>Система выпуска</th>
    </tr>
    <?php
        require("connection/connection.php");
        $selectInformationAboutCharacteristics = "SELECT * FROM `characteristics`";
        $selectInformationAboutCharacteristicsQuery = $autoproConnection->query($selectInformationAboutCharacteristics);
        while($info = $selectInformationAboutCharacteristicsQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
                <td><?php echo $info[6]; ?></td>
                <td><?php echo $info[7]; ?></td>
                <td><?php echo $info[8]; ?></td>
                <td><?php echo $info[9]; ?></td>
                <td><?php echo $info[10]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление комплектации </div>

    <form class="operation_form" name="addCharacteristicForm" method="post">
        <div class="addCharacteristic">
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="characteristicName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите страну производитель: </div>
                <textarea class="textareaClass" name="producingCountry"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID двигателя: </div>
                <select class="selectClass" name="engineID">
                <?php require("connection/connection.php");
                $selectEngine = "SELECT `engine`.id, `engine`.name FROM `engine`";
                $selectEngineQuery = $autoproConnection->query($selectEngine);
                while($engine = $selectEngineQuery->fetch_array())
                {?>
                    <option><?php echo $engine['id'], " - ", $engine['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID трансмиссии: </div>
                <select class="selectClass" name="transmissionID">
                <?php require("connection/connection.php");
                $selectTransmission = "SELECT `transmission`.id, `transmission`.name FROM `transmission`";
                $selectTransmissionQuery = $autoproConnection->query($selectTransmission);
                while($transmission = $selectTransmissionQuery->fetch_array())
                {?>
                    <option><?php echo $transmission['id'], " - ", $transmission['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID системы охлаждения: </div>
                <select class="selectClass" name="coolingSystemID">
                <?php require("connection/connection.php");
                $selectCoolingSystem = "SELECT `coolingSystem`.id, `coolingSystem`.name FROM `coolingSystem`";
                $selectCoolingSystemQuery = $autoproConnection->query($selectCoolingSystem);
                while($coolingSystem = $selectCoolingSystemQuery->fetch_array())
                {?>
                    <option><?php echo $coolingSystem['id'], " - ", $coolingSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID тормозной системы: </div>
                <select class="selectClass" name="brakeSystemID">
                <?php require("connection/connection.php");
                $selectBrakeSystem = "SELECT `brakeSystem`.id, `brakeSystem`.name FROM `brakeSystem`";
                $selectBrakeSystemQuery = $autoproConnection->query($selectBrakeSystem);
                while($brakeSystem = $selectBrakeSystemQuery->fetch_array())
                {?>
                    <option><?php echo $brakeSystem['id'], " - ", $brakeSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID электрооборудования: </div>
                <select class="selectClass" name="electronicsID">
                <?php require("connection/connection.php");
                $selectElectronics = "SELECT `electronics`.id, `electronics`.name FROM `electronics`";
                $selectElectronicsQuery = $autoproConnection->query($selectElectronics);
                while($electronics = $selectElectronicsQuery->fetch_array())
                {?>
                    <option><?php echo $electronics['id'], " - ", $electronics['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID рулевой системы: </div>
                <select class="selectClass" name="steeringSystemID">
                <?php require("connection/connection.php");
                $selectSteeringSystem = "SELECT `steeringSystem`.id, `steeringSystem`.name FROM `steeringSystem`";
                $selectSteeringSystemQuery = $autoproConnection->query($selectSteeringSystem);
                while($steeringSystem = $selectSteeringSystemQuery->fetch_array())
                {?>
                    <option><?php echo $steeringSystem['id'], " - ", $steeringSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID ходовой системы: </div>
                <select class="selectClass" name="runningSystemID">
                <?php require("connection/connection.php");
                $selectRunningSystem = "SELECT `runningSystem`.id, `runningSystem`.name FROM `runningSystem`";
                $selectRunningSystemQuery = $autoproConnection->query($selectRunningSystem);
                while($runningSystem = $selectRunningSystemQuery->fetch_array())
                {?>
                    <option><?php echo $runningSystem['id'], " - ", $runningSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID системы выпуска: </div>
                <select class="selectClass" name="releaseSystemID">
                <?php require("connection/connection.php");
                $selectReleaseSystem = "SELECT `releaseSystem`.id, `releaseSystem`.name FROM `releaseSystem`";
                $selectReleaseSystemQuery = $autoproConnection->query($selectReleaseSystem);
                while($releaseSystem = $selectReleaseSystemQuery->fetch_array())
                {?>
                    <option><?php echo $releaseSystem['id'], " - ", $releaseSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
        
            <input class="submitButton" type="submit" name="addCharacteristicsButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Изменение комплектации </div>

    <form class="operation_form" name="updateCharacteristicsForm" method="post">
        <div class="updateCharacteristics">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID комплектации: </div>
                <select class="selectClass" name="characteristicsID">
                <?php require("connection/connection.php");
                $selectCharacteristicsID = "SELECT `characteristics`.id FROM `characteristics`";
                $selectCharacteristicsIDQuery = $autoproConnection->query($selectCharacteristicsID);
                while($characteristicsID = $selectCharacteristicsIDQuery->fetch_array())
                {?>
                    <option><?php echo $characteristicsID['id']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите наименование: </div>
                <textarea class="textareaClass" name="characteristicName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите страну производитель: </div>
                <textarea class="textareaClass" name="producingCountry"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID двигателя: </div>
                <select class="selectClass" name="engineID">
                <?php require("connection/connection.php");
                $selectEngine = "SELECT `engine`.id, `engine`.name FROM `engine`";
                $selectEngineQuery = $autoproConnection->query($selectEngine);
                while($engine = $selectEngineQuery->fetch_array())
                {?>
                    <option><?php echo $engine['id'], " - ", $engine['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID трансмиссии: </div>
                <select class="selectClass" name="transmissionID">
                <?php require("connection/connection.php");
                $selectTransmission = "SELECT `transmission`.id, `transmission`.name FROM `transmission`";
                $selectTransmissionQuery = $autoproConnection->query($selectTransmission);
                while($transmission = $selectTransmissionQuery->fetch_array())
                {?>
                    <option><?php echo $transmission['id'], " - ", $transmission['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID системы охлаждения: </div>
                <select class="selectClass" name="coolingSystemID">
                <?php require("connection/connection.php");
                $selectCoolingSystem = "SELECT `coolingSystem`.id, `coolingSystem`.name FROM `coolingSystem`";
                $selectCoolingSystemQuery = $autoproConnection->query($selectCoolingSystem);
                while($coolingSystem = $selectCoolingSystemQuery->fetch_array())
                {?>
                    <option><?php echo $coolingSystem['id'], " - ", $coolingSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID тормозной системы: </div>
                <select class="selectClass" name="brakeSystemID">
                <?php require("connection/connection.php");
                $selectBrakeSystem = "SELECT `brakeSystem`.id, `brakeSystem`.name FROM `brakeSystem`";
                $selectBrakeSystemQuery = $autoproConnection->query($selectBrakeSystem);
                while($brakeSystem = $selectBrakeSystemQuery->fetch_array())
                {?>
                    <option><?php echo $brakeSystem['id'], " - ", $brakeSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID электрооборудования: </div>
                <select class="selectClass" name="electronicsID">
                <?php require("connection/connection.php");
                $selectElectronics = "SELECT `electronics`.id, `electronics`.name FROM `electronics`";
                $selectElectronicsQuery = $autoproConnection->query($selectElectronics);
                while($electronics = $selectElectronicsQuery->fetch_array())
                {?>
                    <option><?php echo $electronics['id'], " - ", $electronics['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID рулевой системы: </div>
                <select class="selectClass" name="steeringSystemID">
                <?php require("connection/connection.php");
                $selectSteeringSystem = "SELECT `steeringSystem`.id, `steeringSystem`.name FROM `steeringSystem`";
                $selectSteeringSystemQuery = $autoproConnection->query($selectSteeringSystem);
                while($steeringSystem = $selectSteeringSystemQuery->fetch_array())
                {?>
                    <option><?php echo $steeringSystem['id'], " - ", $steeringSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID ходовой системы: </div>
                <select class="selectClass" name="runningSystemID">
                <?php require("connection/connection.php");
                $selectRunningSystem = "SELECT `runningSystem`.id, `runningSystem`.name FROM `runningSystem`";
                $selectRunningSystemQuery = $autoproConnection->query($selectRunningSystem);
                while($runningSystem = $selectRunningSystemQuery->fetch_array())
                {?>
                    <option><?php echo $runningSystem['id'], " - ", $runningSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID системы выпуска: </div>
                <select class="selectClass" name="releaseSystemID">
                <?php require("connection/connection.php");
                $selectReleaseSystem = "SELECT `releaseSystem`.id, `releaseSystem`.name FROM `releaseSystem`";
                $selectReleaseSystemQuery = $autoproConnection->query($selectReleaseSystem);
                while($releaseSystem = $selectReleaseSystemQuery->fetch_array())
                {?>
                    <option><?php echo $releaseSystem['id'], " - ", $releaseSystem['name']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>

            <input class="submitButton" type="submit" name="updateCharacteristicsButton" value="Изменить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление комплектации </div>

    <form class="operation_form" name="deleteCharacteristicsForm" method="post">
        <div class="deleteCharacteristics">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID комплектации: </div>
                <select class="selectClass" name="characteristicsID">
                <?php require("connection/connection.php");
                $selectCharacteristicsID = "SELECT `characteristics`.id FROM `characteristics`";
                $selectCharacteristicsIDQuery = $autoproConnection->query($selectCharacteristicsID);
                while($characteristicsID = $selectCharacteristicsIDQuery->fetch_array())
                {?>
                    <option><?php echo $characteristicsID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteCharacteristicsButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 