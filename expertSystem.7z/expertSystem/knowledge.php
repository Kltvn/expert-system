<?php
    if(isset($_POST['addRuleButton']))
    {
        $fact = $_POST['fact'];
        $rule = $_POST['rule'];
        $result = $_POST['result'];
        $ruleExplanation = $_POST['ruleExplanation'];
        $ruleObject = $_POST['ruleObject'];

        if(!empty($ruleExplanation))
        {
            require("connection/expertSystemConnection.php");
            $ruleClass = new Rule();
            $ruleClass->AddNewRule($fact[0], $rule, $result[0], $ruleExplanation, $ruleObject);
            header("Location: http://expertsystem/knowledge.php");
        }
    }

    if(isset($_POST['deleteRuleButton']))
    {
        $ruleID = $_POST['ruleID'];

        require("connection/expertSystemConnection.php");
        $ruleClass = new Rule();
        $ruleClass->RemoveRule($ruleID);
        header("Location: http://expertsystem/knowledge.php");
    }

    if(isset($_POST['addFactButton']))
    {
        $variable = $_POST['variable'];
        $domain = $_POST['domain'];
        $annotation = $_POST['annotation'];

        if(!empty($annotation))
        {
            require("connection/expertSystemConnection.php");
            $factClass = new Fact();
            $ruleClass->AddNewFact($variable, $domain[0], $annotation);
            header("Location: http://expertsystem/knowledge.php");
        }
    }

    if(isset($_POST['deleteFactButton']))
    {
        $factID = $_POST['factID'];

        require("connection/expertSystemConnection.php");
        $factClass = new Fact();
        $ruleClass->RemoveFact($factID);
        header("Location: http://expertsystem/knowledge.php");
    }

    if(isset($_POST['addDomainButton']))
    {
        $domainName = $_POST['domainName'];
        $domainValue = $_POST['domainValue'];
        $domainPrice = $_POST['domainPrice'];

        if(!empty($domainValue) && !is_int($domainPrice))
        {
            require("connection/expertSystemConnection.php");
            $domainClass = new Domain();
            $domainClass->AddNewDomain($domainName, $domainValue, $domainPrice);
            header("Location: http://expertsystem/knowledge.php");
        }
    }

    if(isset($_POST['deleteDomainButton']))
    {
        $domainID = $_POST['domainID'];

        require("connection/expertSystemConnection.php");
        $domainClass = new Domain();
        $domainClass->RemoveDomain($domainID[1]);
        header("Location: http://expertsystem/knowledge.php");
    }

    if(isset($_POST['addVariableButton']))
    {
        $variableName = $_POST['variableName'];
        $variableType = $_POST['variableType'];
        $variableQuestion = $_POST['variableQuestion'];

        if(!empty($variableName) && !empty($variableQuestion))
        {
            require("connection/expertSystemConnection.php");
            $variableClass = new Variable();
            $variableClass->AddNewVariable($variableName, $variableType, $variableQuestion);
            header("Location: http://expertsystem/knowledge.php");
        }
    }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="autopro.css"/>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Cantata+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,700;1,300&display=swap" rel="stylesheet">
<title> База знаний </title>
</head>

<body>

<header class="header">
    <div class="header_items">
        <div class="logo"> 
            <img src="images/logo.png" width="250px" height="70px">
        </div>

        <nav class="nav">
		    <a class="nav_button" href="http://expertsystem/contracts.php"> Заказы </a>
		    <a class="nav_button" href="http://expertsystem/clients.php"> База клиентов </a>
            <a class="nav_button" href="http://expertsystem/cars.php"> База автомобилей </a>
		    <a class="nav_button" href="http://expertsystem/masters.php"> База сотрудников </a>
            <a class="nav_button" href="http://expertsystem/knowledge.php"> База  знаний</a>
            <a class="nav_button" href="http://expertsystem/guide.php"> О программе </a>
	    </nav>
    </div>
</header>

<div class="title">
    <div class="subtitle_first"> Правила </div>
</div>

<div class="clients">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Номер факта</th>
        <th>Ссылка на правило</th>
        <th>Результат</th>
        <th>Объяснение</th>
        <th>Объект</th>
    </tr>
    <?php
        require("connection/expertSystemConnection.php");
        $selectInformationAboutRules = "SELECT * FROM `rule`";
        $selectInformationAboutRulesQuery = $expertSystemConnection->query($selectInformationAboutRules);
        while($info = $selectInformationAboutRulesQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
                <td><?php echo $info[4]; ?></td>
                <td><?php echo $info[5]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление правила </div>

    <form class="operation_form" name="addRuleForm" method="post">
        <div class="addRule">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите номер факта: </div>
                <select class="selectClass" name="fact">
                <?php require("connection/expertSystemConnection.php");
                $selectFact = "SELECT `fact`.id, `fact`.annotation FROM `fact`";
                $selectFactQuery = $expertSystemConnection->query($selectFact);
                while($fact = $selectFactQuery->fetch_array())
                {?>
                    <option><?php echo $fact['id'], " - ", $fact['annotation']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ссылку на правило (ИЛИ NULL): </div>
                <select class="selectClass" name="rule">
                    <option> NULL </option>
                <?php require("connection/expertSystemConnection.php");
                $selectRule = "SELECT `rule`.id FROM `rule`";
                $selectRuleQuery = $expertSystemConnection->query($selectRule);
                while($rule = $selectRuleQuery->fetch_array())
                {?>
                    <option><?php echo $rule['id']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите результат: </div>
                <select class="selectClass" name="result">
                <?php require("connection/expertSystemConnection.php");
                $selectResult = "SELECT `fact`.id, `fact`.annotation FROM `fact`
                WHERE `fact`.variable_id = '52' OR `fact`.variable_id = '53'";
                $selectResultQuery = $expertSystemConnection->query($selectResult);
                while($result = $selectResultQuery->fetch_array())
                {?>
                    <option><?php echo $result['id'], " - ", $result['annotation']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите объяснение для правила: </div>
                <textarea class="rule-explanation" name="ruleExplanation"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите объект: </div>
                <select class="selectClass" name="ruleObject">
                    <option> Двигатель </option>
                    <option> Трансмиссия </option>
                    <option> Система охлаждения </option>
                    <option> Электрооборудование </option>
                    <option> Тормозная система </option>
                    <option> Рулевое управление </option>
                    <option> Ходовая часть </option>
                    <option> Система выпуска </option>
                    <option> Расходники </option>
                </select>
            </div>

            <input class="submitButton" type="submit" name="addRuleButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление правила </div>

    <form class="operation_form" name="deleteRuleForm" method="post">
        <div class="deleteRule">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID правила: </div>
                <select class="selectClass" name="ruleID">
                <?php require("connection/expertSystemConnection.php");
                $selectRuleID = "SELECT `rule`.id FROM `rule`";
                $selectRuleIDQuery = $expertSystemConnection->query($selectRuleID);
                while($ruleID = $selectRuleIDQuery->fetch_array())
                {?>
                    <option><?php echo $ruleID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteRuleButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Факты </div>
</div>

<div class="clients">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Номер переменной</th>
        <th>Номер домена</th>
        <th>Пояснение</th>
    </tr>
    <?php
        require("connection/expertSystemConnection.php");
        $selectInformationAboutFacts = "SELECT * FROM `fact`";
        $selectInformationAboutFactsQuery = $expertSystemConnection->query($selectInformationAboutFacts);
        while($info = $selectInformationAboutFactsQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление факта </div>

    <form class="operation_form" name="addFactForm" method="post">
        <div class="addFact">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите номер переменной: </div>
                <select class="selectClass" name="variable">
                <?php require("connection/expertSystemConnection.php");
                $selectVariable = "SELECT `variable`.id FROM `variable`";
                $selectVariableQuery = $expertSystemConnection->query($selectVariable);
                while($variable = $selectVariableQuery->fetch_array())
                {?>
                    <option><?php echo $variable['id']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите номер домена: </div>
                <select class="selectClass" name="domain">
                <?php require("connection/expertSystemConnection.php");
                $selectDomain = "SELECT `domain`.id, `domain`.value FROM `domain`";
                $selectDomainQuery = $expertSystemConnection->query($selectDomain);
                while($domain = $selectDomainQuery->fetch_array())
                {?>
                    <option><?php echo $domain['id'], " - ", $domain['value']; ?></option> <?php
                }           
	            ?>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите пояснение для факта: </div>
                <textarea class="rule-explanation" name="annotation"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addFactButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление факта </div>

    <form class="operation_form" name="deleteFactForm" method="post">
        <div class="deleteFact">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID факта: </div>
                <select class="selectClass" name="factID">
                <?php require("connection/expertSystemConnection.php");
                $selectFactID = "SELECT `fact`.id FROM `fact`";
                $selectFactIDQuery = $expertSystemConnection->query($selectFactID);
                while($factID = $selectFactIDQuery->fetch_array())
                {?>
                    <option><?php echo $factID['id']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteFactButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>

<div class="title">
    <div class="subtitle_first"> Домены </div>
</div>

<div class="clients">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Имя домена</th>
        <th>Значение</th>
    </tr>
    <?php
        require("connection/expertSystemConnection.php");
        $selectInformationAboutDomains = "SELECT * FROM `domain`";
        $selectInformationAboutDomainsQuery = $expertSystemConnection->query($selectInformationAboutDomains);
        while($info = $selectInformationAboutDomainsQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление домена </div>

    <form class="operation_form" name="addDomainForm" method="post">
        <div class="addDomain">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите имя домена: </div>
                <select class="selectClass" name="domainName">
                    <option> Услуга </option>
                    <option> Рекомендация </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите значение для домена: </div>
                <textarea class="rule-explanation" name="domainValue"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите стоимость услуги: </div>
                <textarea class="textareaClass" name="domainPrice"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addDomainButton" value="Добавить"> </input>
        </div>
    </form>
</div>

<div class="order">
    <div class="subtitle_first"> Удаление домена </div>

    <form class="operation_form" name="deleteDomainForm" method="post">
        <div class="deleteDomain">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите ID домена: </div>
                <select class="selectClass" name="domainID">
                <?php require("connection/expertSystemConnection.php");
                $selectDomainID = "SELECT `domain`.id, `domain`.value FROM `domain`
                WHERE `domain`.value != 'Да' AND `domain`.value != 'Нет'";
                $selectDomainIDQuery = $expertSystemConnection->query($selectDomainID);
                while($domainID = $selectDomainIDQuery->fetch_array())
                {?>
                    <option><?php echo $domainID['id'], " - ", $domainID['value']; ?></option> <?php
                }           
	            ?>
                </select>
                <input class="submitButton" type="submit" name="deleteDomainButton" value="Удалить"> </input>
            </div>            
        </div>
    </form>
</div>
</div>


<div class="title">
    <div class="subtitle_first"> Переменные </div>
</div>

<div class="clients">
<div class="order">
    <div class="contracts_table">
    <table align="center" width="1000px">
    <tr>
        <th>№</th>
        <th>Имя переменной</th>
        <th>Тип переменной</th>
        <th>Вопрос</th>
    </tr>
    <?php
        require("connection/expertSystemConnection.php");
        $selectInformationAboutVariables = "SELECT * FROM `variable`";
        $selectInformationAboutVariablesQuery = $expertSystemConnection->query($selectInformationAboutVariables);
        while($info = $selectInformationAboutVariablesQuery->fetch_array())
        {?>
            <tr>
                <td><?php echo $info[0]; ?></td>
                <td><?php echo $info[1]; ?></td>
                <td><?php echo $info[2]; ?></td>
                <td><?php echo $info[3]; ?></td>
            </tr> <?php
        }
    ?>
    </table>
    </div>

<div class="order">
    <div class="subtitle_first"> Добавление переменной </div>

    <form class="operation_form" name="addVariableForm" method="post">
        <div class="addVariable">
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите имя переменной: </div>
                <textarea class="textareaClass" name="variableName"></textarea>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Выберите тип переменной: </div>
                <select class="selectClass" name="variableType">
                    <option> Вводимая </option>
                    <option> Выводимая </option>
                </select>
            </div>
            <div class="clientInfo">
                <div class="subtitle_second"> Введите текст вопроса: </div>
                <textarea class="rule-explanation" name="variableQuestion"></textarea>
            </div>

            <input class="submitButton" type="submit" name="addVariableButton" value="Добавить"> </input>
        </div>
    </form>
</div>
</div>

<footer class="footer">
    <div class="footer_container">
        <div class="footer_menu">
            <div class="menu_items"> <a href="http://expertsystem/main.php">autoPRO </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/clients.php">Клиенты </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/cars.php">Автомобили </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/masters.php">Сотрудники </a> </div>
            <div class="menu_items"> <a href="http://expertsystem/guide.php">О программе </a> </div>
        </div>

        <div class="social">
            <div class="footer_social">
                <div class="social_items"> <a href="https://vk.com/kltvn" target="_blank"> <i class="fab fa-vk"></i> </a> </div>
                <div class="social_items"> <a href="https://www.instagram.com/a.kltvn/" target="_blank"> <i class="fab fa-instagram"> </i> </a> </div>
                <div class="social_items"> <a href="https://www.facebook.com/profile.php?id=100057889987517" target="_blank"> <i class="fab fa-facebook-f"></i> </a> </div>
            </div>
        </div>
</footer>

<div class="copyright">© 2022 AUTOPRO by kltvn</div>

</body>
</html> 